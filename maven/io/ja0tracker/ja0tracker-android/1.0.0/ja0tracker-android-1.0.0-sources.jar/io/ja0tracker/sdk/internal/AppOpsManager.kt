package io.ja0tracker.sdk.internal

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.ja0tracker.sdk.AppMessage
import io.ja0tracker.sdk.AppMessageFrequency
import io.ja0tracker.sdk.AppMessageType
import io.ja0tracker.sdk.Ja0TrackerConfig
import io.ja0tracker.sdk.UpdateInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Orchestrates the App Ops surface (docs/appops-contract.md §2, §5): fetches the delivery
 * payload on init + periodically, caches remote config, and renders the update popup,
 * in-app messages, and review prompt — honoring per-message frequency and, for reviews,
 * cumulative session time. Also owns push-token registration (§3).
 *
 * Reuses Core infrastructure: [AppOpsClient] (HTTP + HMAC via [Hmac]), [SecureStore] for
 * persistence, [SessionTracker] for session accounting, [ActivityTracker] for a live
 * Activity to attach UI to, and [JsonParser]/[Json] for (de)serialization.
 */
internal class AppOpsManager(
    private val context: Context,
    private val config: Ja0TrackerConfig,
    private val store: SecureStore,
    private val activityTracker: ActivityTracker,
    private val sessionSec: () -> Long,
    private val sessionCount: () -> Long,
    private val installId: () -> String,
    private val platform: String = "android",
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {
    private val client = AppOpsClient(config)
    private val mainHandler = Handler(Looper.getMainLooper())

    // Host overrides. When set, the SDK hands the model + a completion handle to the app
    // instead of showing its default UI (docs/appops-contract.md §5).
    @Volatile var onUpdateAvailable: ((UpdateInfo) -> Unit)? = null
    @Volatile var onMessage: ((AppMessage, () -> Unit) -> Unit)? = null

    // Push consent gate + pending token (host may set the token before consent).
    @Volatile private var pushConsent: Boolean = store.getBoolean(SecureStore.KEY_PUSH_CONSENT, false)
    @Volatile private var pendingPushToken: String? = null

    // Cached parsed config for synchronous getConfig* reads.
    @Volatile private var configCache: Map<String, Any?> = emptyMap()

    private var pollJob: Job? = null

    /** Load the cached config so getConfig* works offline / before the first fetch. */
    fun start() {
        store.getStringKeyed(SecureStore.KEY_APPOPS_CONFIG)?.let { cached ->
            JsonParser.parseObject(cached)?.let { configCache = it }
        }
        // Immediate fetch, then periodic polling.
        fetchNow()
        startPolling()
    }

    fun stop() {
        pollJob?.cancel()
        pollJob = null
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (true) {
                delay(POLL_INTERVAL_MS)
                runCatching { fetchAndApply() }
            }
        }
    }

    /** Kick a one-off fetch (used on init and after identity is ready). */
    fun fetchNow() {
        scope.launch { runCatching { fetchAndApply() } }
    }

    // ---- Remote config ----

    fun getConfigString(key: String, default: String?): String? =
        (configCache[key] as? String) ?: default

    fun getConfigBool(key: String, default: Boolean): Boolean = when (val v = configCache[key]) {
        is Boolean -> v
        is String -> v.equals("true", ignoreCase = true)
        is Number -> v.toInt() != 0
        else -> default
    }

    fun getConfigInt(key: String, default: Int): Int = when (val v = configCache[key]) {
        is Number -> v.toInt()
        is String -> v.toIntOrNull() ?: default
        is Boolean -> if (v) 1 else 0
        else -> default
    }

    /** Returns the raw JSON string for a config value (object/array/scalar) or null. */
    fun getConfigJson(key: String): String? {
        val v = configCache[key] ?: return null
        return Json.encode(v)
    }

    // ---- Push ----

    fun setPushConsent(granted: Boolean) {
        pushConsent = granted
        store.putBoolean(SecureStore.KEY_PUSH_CONSENT, granted)
        // If a token was queued before consent, register it now.
        if (granted) pendingPushToken?.let { setPushToken(it) }
    }

    /**
     * Registers an FCM token (host owns FCM setup). No-op without push consent; the token is
     * queued and sent once consent is granted. Dedups identical re-registrations.
     */
    fun setPushToken(token: String) {
        if (token.isEmpty()) return
        if (!pushConsent) {
            pendingPushToken = token
            Logger.d("push token held until consent granted")
            return
        }
        if (store.getStringKeyed(SecureStore.KEY_PUSH_TOKEN) == token) return
        pendingPushToken = null
        scope.launch {
            val ok = client.registerPush(platform, installId(), token, deviceLang())
            if (ok) store.putStringKeyed(SecureStore.KEY_PUSH_TOKEN, token)
        }
    }

    // ---- Fetch + apply ----

    private fun fetchAndApply() {
        val id = installId()
        if (id.isEmpty()) return
        val payload = client.fetch(
            platform = platform,
            appVersion = appVersion(),
            lang = deviceLang(),
            installId = id,
            sessionSec = sessionSec(),
            sessionCount = sessionCount(),
        ) ?: return

        // 1. Cache remote config.
        (payload["config"] as? Map<*, *>)?.let { raw ->
            @Suppress("UNCHECKED_CAST")
            val cfg = raw as Map<String, Any?>
            configCache = cfg
            store.putStringKeyed(SecureStore.KEY_APPOPS_CONFIG, Json.encode(cfg))
        }

        // 2. Update popup.
        (payload["update"] as? Map<*, *>)?.let { applyUpdate(parseUpdate(it)) }

        // 3. Messages by priority (highest first).
        val messages = parseMessages(payload["messages"])
            .sortedByDescending { it.priority }
        for (msg in messages) {
            applyMessage(msg)
        }
    }

    private fun applyUpdate(update: UpdateInfo) {
        if (!update.available) return
        val cb = onUpdateAvailable
        if (cb != null) {
            deliverOnMain { cb(update) }
            return
        }
        val activity = activityTracker.currentActivity ?: return
        deliverOnMain {
            AppOpsUi.showUpdateDialog(
                activity = activity,
                title = update.title,
                body = update.body,
                ctaText = null,
                storeUrl = update.storeUrl,
                force = update.force,
            )
        }
    }

    private fun applyMessage(msg: AppMessage) {
        if (!shouldShow(msg)) return

        // Review flow is native-first regardless of custom UI callback.
        if (msg.type == AppMessageType.REVIEW) {
            if (sessionSec() < msg.minSessionSec) return
            triggerReview(msg)
            return
        }

        val cb = onMessage
        if (cb != null) {
            deliverOnMain { cb(msg) { markShown(msg) } }
            return
        }
        val activity = activityTracker.currentActivity ?: return
        deliverOnMain {
            AppOpsUi.showMessageDialog(
                activity = activity,
                title = msg.title,
                body = msg.body,
                ctaText = msg.ctaText,
                ctaUrl = msg.ctaUrl,
                force = msg.force,
                onShown = { markShown(msg) },
            )
        }
    }

    private fun triggerReview(msg: AppMessage) {
        // Allow the host to fully own the review UX if it registered onMessage.
        val cb = onMessage
        if (cb != null) {
            deliverOnMain { cb(msg) { markShown(msg) } }
            return
        }
        val activity = activityTracker.currentActivity ?: return
        deliverOnMain {
            PlayReview.request(
                activity = activity,
                onCompleted = { markShown(msg) },
                onUnavailable = {
                    AppOpsUi.showReviewFallbackDialog(
                        activity = activity,
                        title = msg.title,
                        body = msg.body,
                        ctaText = msg.ctaText,
                        storeUrl = msg.ctaUrl,
                        onShown = { markShown(msg) },
                    )
                },
            )
        }
    }

    // ---- Frequency ----

    private fun shouldShow(msg: AppMessage): Boolean {
        val key = SecureStore.KEY_MSG_SHOWN_PREFIX + msg.id
        val last = store.getLong(key, 0L)
        return when (msg.frequency) {
            AppMessageFrequency.ALWAYS -> true
            AppMessageFrequency.ONCE -> last == 0L
            AppMessageFrequency.DAILY -> System.currentTimeMillis() - last >= DAY_MS
            // "session": shown at most once per app process (not persisted across restarts).
            AppMessageFrequency.SESSION -> !shownThisSession.contains(msg.id)
        }
    }

    private fun markShown(msg: AppMessage) {
        val key = SecureStore.KEY_MSG_SHOWN_PREFIX + msg.id
        store.putLong(key, System.currentTimeMillis())
        shownThisSession.add(msg.id)
    }

    private val shownThisSession = java.util.Collections.synchronizedSet(HashSet<String>())

    // ---- Parsing ----

    private fun parseUpdate(raw: Map<*, *>): UpdateInfo = UpdateInfo(
        available = raw["available"] as? Boolean ?: false,
        force = raw["force"] as? Boolean ?: false,
        latestVersion = raw["latest_version"] as? String,
        storeUrl = raw["store_url"] as? String,
        title = raw["title"] as? String,
        body = raw["body"] as? String,
    )

    private fun parseMessages(raw: Any?): List<AppMessage> {
        val list = raw as? List<*> ?: return emptyList()
        return list.mapNotNull { item ->
            val m = item as? Map<*, *> ?: return@mapNotNull null
            val id = m["id"] as? String ?: return@mapNotNull null
            AppMessage(
                id = id,
                type = AppMessageType.from(m["type"] as? String),
                priority = (m["priority"] as? Number)?.toInt() ?: 0,
                title = m["title"] as? String,
                body = m["body"] as? String,
                ctaText = m["cta_text"] as? String,
                ctaUrl = m["cta_url"] as? String,
                imageUrl = m["image_url"] as? String,
                force = m["force"] as? Boolean ?: false,
                minSessionSec = (m["min_session_sec"] as? Number)?.toInt() ?: 0,
                frequency = AppMessageFrequency.from(m["frequency"] as? String),
            )
        }
    }

    // ---- Device context ----

    /** Device language code (e.g. "ko"/"en"), defaulting to "en" (docs/appops-contract §6). */
    private fun deviceLang(): String {
        val lang = Locale.getDefault().language
        return if (lang.isNullOrBlank()) "en" else lang
    }

    private fun appVersion(): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
    } catch (t: Throwable) {
        ""
    }

    private fun deliverOnMain(block: () -> Unit) {
        mainHandler.post {
            try {
                block()
            } catch (t: Throwable) {
                Logger.e("appops UI error", t)
            }
        }
    }

    companion object {
        private const val POLL_INTERVAL_MS = 30 * 60 * 1000L // 30 minutes
        private const val DAY_MS = 24 * 60 * 60 * 1000L
    }
}
