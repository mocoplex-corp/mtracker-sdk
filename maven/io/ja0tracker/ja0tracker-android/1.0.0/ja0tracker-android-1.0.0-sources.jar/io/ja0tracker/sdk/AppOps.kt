package io.ja0tracker.sdk

/**
 * App Ops public models (docs/appops-contract.md §2, §5).
 *
 * These are the localized, server-resolved surfaces the SDK renders: a version-update
 * prompt, in-app messages / announcements / review prompts, and the remote-config map.
 * All user-facing text is already resolved to the device language by the server (§6),
 * so the SDK just renders whatever it receives.
 *
 * The host app can override the default UI by registering [Ja0Tracker.onUpdateAvailable]
 * / [Ja0Tracker.onMessage]; the callbacks receive these models plus a completion handle so
 * a custom flow can report the outcome back (e.g. mark a review prompt shown).
 */

/** A server-driven version-update prompt (docs/appops-contract.md §2 `update`). */
data class UpdateInfo(
    /** True when a newer store version is available for this platform. */
    val available: Boolean,
    /** True when the current version is below `version_min` — the popup is blocking. */
    val force: Boolean,
    /** Latest store version string (e.g. "1.2.0"), if known. */
    val latestVersion: String?,
    /** Store listing URL to open on the CTA. */
    val storeUrl: String?,
    /** Localized dialog title (server-resolved). */
    val title: String?,
    /** Localized dialog body (server-resolved). */
    val body: String?,
)

/** Type of an in-app message (docs/appops-contract.md §1 `app_messages.type`). */
enum class AppMessageType {
    UPDATE,
    ANNOUNCEMENT,
    REVIEW,
    CUSTOM;

    companion object {
        fun from(raw: String?): AppMessageType = when (raw?.lowercase()) {
            "update" -> UPDATE
            "review" -> REVIEW
            "custom" -> CUSTOM
            else -> ANNOUNCEMENT
        }
    }
}

/** How often a message may be shown (docs/appops-contract.md §1 `frequency`). */
enum class AppMessageFrequency {
    ONCE,
    SESSION,
    DAILY,
    ALWAYS;

    companion object {
        fun from(raw: String?): AppMessageFrequency = when (raw?.lowercase()) {
            "once" -> ONCE
            "session" -> SESSION
            "daily" -> DAILY
            else -> ALWAYS
        }
    }
}

/**
 * A single in-app message / announcement / review prompt (docs/appops-contract.md §2
 * `messages[]`). Text fields are already localized to the device language by the server.
 */
data class AppMessage(
    val id: String,
    val type: AppMessageType,
    val priority: Int,
    val title: String?,
    val body: String?,
    val ctaText: String?,
    val ctaUrl: String?,
    val imageUrl: String?,
    /** True for a blocking/force message (mirrors update.force for type=update). */
    val force: Boolean,
    /** Cumulative foreground seconds required before a review prompt fires. */
    val minSessionSec: Int,
    val frequency: AppMessageFrequency,
)
