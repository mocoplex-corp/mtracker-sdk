package io.ja0tracker.sdk.internal

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Durable, at-rest-encrypted storage for the SDK's identity + first-launch state
 * (docs/sdk-contract.md §4). Backs the `install_id`, the first-launch flag, and the
 * consent snapshot.
 *
 * Uses AndroidX Security `EncryptedSharedPreferences` (AES-256-GCM, key in the
 * Android Keystore). Keystore/crypto init can occasionally fail (corrupt keyset,
 * OEM keystore bugs, direct-boot), so we fall back to a plain SharedPreferences
 * file rather than crashing the host app — the values stored are non-secret device
 * identifiers, and availability of a stable install_id matters more than encryption.
 */
internal class SecureStore(context: Context) {

    private val prefs: SharedPreferences = openPrefs(context.applicationContext)

    private fun openPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                ENCRYPTED_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (t: Throwable) {
            // Fall back to a plaintext file so identity/first-launch still work.
            context.getSharedPreferences(FALLBACK_FILE, Context.MODE_PRIVATE)
        }
    }

    fun getString(key: String): String? = prefs.getString(key, null)

    fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getBoolean(key: String, default: Boolean): Boolean =
        prefs.getBoolean(key, default)

    fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun getLong(key: String, default: Long): Long =
        prefs.getLong(key, default)

    fun putLong(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
    }

    /** Namespaced string get/put for arbitrary App Ops keys (config cache, frequency guards). */
    fun getStringKeyed(key: String): String? = prefs.getString(key, null)

    fun putStringKeyed(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun contains(key: String): Boolean = prefs.contains(key)

    companion object {
        private const val ENCRYPTED_FILE = "mtracker_secure_store"
        private const val FALLBACK_FILE = "mtracker_store"

        const val KEY_INSTALL_ID = "install_id"
        const val KEY_FIRST_LAUNCH_DONE = "first_launch_done"
        const val KEY_REFERRER_FETCHED = "referrer_fetched"
        const val KEY_APP_VERSION = "app_version"
        const val KEY_CONSENT_ANALYTICS = "consent_analytics"
        const val KEY_CONSENT_ATTRIBUTION = "consent_attribution"
        const val KEY_CONSENT_ADS = "consent_ads"

        // ---- App Ops (docs/appops-contract.md §5) ----
        /** Cached remote-config JSON object (getConfig* reads from this offline). */
        const val KEY_APPOPS_CONFIG = "appops_config"
        /** Cumulative foreground seconds (drives review-prompt min_session_sec). */
        const val KEY_SESSION_SEC_TOTAL = "appops_session_sec_total"
        /** Total number of sessions opened (sent as session_count). */
        const val KEY_SESSION_COUNT = "appops_session_count"
        /** Push consent gate — POST /v1/push/register only when granted. */
        const val KEY_PUSH_CONSENT = "appops_push_consent"
        /** Last push token successfully registered (dedup re-registration). */
        const val KEY_PUSH_TOKEN = "appops_push_token"
        /** Per-message frequency guard prefix: appops_msg_<id> -> last-shown epoch millis. */
        const val KEY_MSG_SHOWN_PREFIX = "appops_msg_"
    }
}
