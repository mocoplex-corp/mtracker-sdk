package io.ja0tracker.sdk.internal

/**
 * Minimal, dependency-free JSON writer.
 *
 * The event batch body is HMAC-signed byte-for-byte (docs/sdk-contract.md §2), so
 * the SDK must control the *exact* serialized bytes. Pulling in a full JSON library
 * (kotlinx.serialization / Gson) works too, but a tiny hand-rolled writer keeps the
 * AAR light and removes any ambiguity about escaping / key ordering / whitespace.
 *
 * Emits compact JSON (no insignificant whitespace). Only the value types the SDK
 * actually produces are supported: String, Boolean, null, numbers, Map, List/Array.
 */
internal object Json {

    fun encode(value: Any?): String {
        val sb = StringBuilder()
        writeValue(sb, value)
        return sb.toString()
    }

    private fun writeValue(sb: StringBuilder, value: Any?) {
        when (value) {
            null -> sb.append("null")
            is JsonRaw -> sb.append(value.text)
            is String -> writeString(sb, value)
            is Boolean -> sb.append(if (value) "true" else "false")
            is Int, is Long, is Short, is Byte -> sb.append(value.toString())
            is Double -> writeDouble(sb, value)
            is Float -> writeDouble(sb, value.toDouble())
            is Number -> sb.append(value.toString())
            is Map<*, *> -> writeObject(sb, value)
            is Iterable<*> -> writeArray(sb, value)
            is Array<*> -> writeArray(sb, value.asIterable())
            is IntArray -> writeArray(sb, value.asIterable())
            is LongArray -> writeArray(sb, value.asIterable())
            is DoubleArray -> writeArray(sb, value.asIterable())
            is BooleanArray -> writeArray(sb, value.asIterable())
            // Unknown types are stringified defensively rather than throwing.
            else -> writeString(sb, value.toString())
        }
    }

    private fun writeObject(sb: StringBuilder, map: Map<*, *>) {
        sb.append('{')
        var first = true
        for ((k, v) in map) {
            if (k == null) continue
            if (!first) sb.append(',')
            first = false
            writeString(sb, k.toString())
            sb.append(':')
            writeValue(sb, v)
        }
        sb.append('}')
    }

    private fun writeArray(sb: StringBuilder, items: Iterable<*>) {
        sb.append('[')
        var first = true
        for (item in items) {
            if (!first) sb.append(',')
            first = false
            writeValue(sb, item)
        }
        sb.append(']')
    }

    private fun writeDouble(sb: StringBuilder, d: Double) {
        // JSON has no NaN/Infinity; coerce to null to keep output valid.
        if (d.isNaN() || d.isInfinite()) {
            sb.append("null")
            return
        }
        // Render whole doubles without a trailing ".0" so revenue like 9900.0
        // encodes as 9900 (matches typical integer expectations server-side).
        if (d == Math.floor(d) && !d.isInfinite() && Math.abs(d) < 1e15) {
            sb.append(d.toLong().toString())
        } else {
            sb.append(d.toString())
        }
    }

    private fun writeString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> {
                    if (c < ' ') {
                        sb.append("\\u")
                        sb.append(HEX[(c.code shr 12) and 0xF])
                        sb.append(HEX[(c.code shr 8) and 0xF])
                        sb.append(HEX[(c.code shr 4) and 0xF])
                        sb.append(HEX[c.code and 0xF])
                    } else {
                        sb.append(c)
                    }
                }
            }
        }
        sb.append('"')
    }

    private val HEX = "0123456789abcdef".toCharArray()
}

/** Wrap a pre-serialized JSON fragment so it is emitted verbatim (e.g. stored params). */
internal class JsonRaw(val text: String)
