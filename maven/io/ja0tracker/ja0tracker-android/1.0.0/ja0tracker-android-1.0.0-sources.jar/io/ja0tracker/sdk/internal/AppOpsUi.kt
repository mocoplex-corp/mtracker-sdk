package io.ja0tracker.sdk.internal

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri

/**
 * Default in-SDK UI for App Ops surfaces (docs/appops-contract.md §5). Deliberately built
 * on the platform [AlertDialog] so the SDK ships no layout resources and no extra deps.
 * The host app can bypass all of this by registering onUpdateAvailable / onMessage.
 *
 * All dialogs are shown on the current foreground Activity and are safe to skip when none
 * is available (the caller retries on the next fetch cycle).
 */
internal object AppOpsUi {

    /**
     * Shows the version-update prompt. When [force] the dialog is non-dismissible (blocking)
     * and only offers the update CTA; otherwise a "Later" button dismisses it.
     */
    fun showUpdateDialog(
        activity: Activity,
        title: String?,
        body: String?,
        ctaText: String?,
        storeUrl: String?,
        force: Boolean,
    ) {
        val builder = AlertDialog.Builder(activity)
            .setTitle(title ?: "Update available")
            .setMessage(body ?: "A new version is available.")
            .setCancelable(!force)
            .setPositiveButton(ctaText ?: "Update") { d, _ ->
                openUrl(activity, storeUrl)
                d.dismiss()
            }
        if (!force) {
            builder.setNegativeButton("Later") { d, _ -> d.dismiss() }
        }
        val dialog = builder.create()
        // Block dismissal-by-back for force updates.
        dialog.setCanceledOnTouchOutside(!force)
        dialog.show()
    }

    /**
     * Shows a generic announcement/custom message dialog. [onCta] fires after the CTA (or
     * URL open) so the caller can record the frequency guard.
     */
    fun showMessageDialog(
        activity: Activity,
        title: String?,
        body: String?,
        ctaText: String?,
        ctaUrl: String?,
        force: Boolean,
        onShown: () -> Unit,
    ) {
        val builder = AlertDialog.Builder(activity)
            .setTitle(title ?: "")
            .setMessage(body ?: "")
            .setCancelable(!force)
            .setPositiveButton(ctaText ?: "OK") { d, _ ->
                if (!ctaUrl.isNullOrEmpty()) openUrl(activity, ctaUrl)
                d.dismiss()
            }
        if (!force) {
            builder.setNegativeButton("Dismiss") { d, _ -> d.dismiss() }
        }
        builder.create().apply { setCanceledOnTouchOutside(!force) }.show()
        onShown()
    }

    /**
     * Fallback review dialog when Play In-App Review is unavailable: a simple prompt that
     * routes the user to the store listing (docs/appops-contract.md §5 "falling back to a
     * custom dialog + store link").
     */
    fun showReviewFallbackDialog(
        activity: Activity,
        title: String?,
        body: String?,
        ctaText: String?,
        storeUrl: String?,
        onShown: () -> Unit,
    ) {
        AlertDialog.Builder(activity)
            .setTitle(title ?: "Enjoying the app?")
            .setMessage(body ?: "Would you mind leaving a review?")
            .setPositiveButton(ctaText ?: "Rate") { d, _ ->
                openUrl(activity, storeUrl)
                d.dismiss()
            }
            .setNegativeButton("Not now") { d, _ -> d.dismiss() }
            .show()
        onShown()
    }

    fun openUrl(activity: Activity, url: String?) {
        if (url.isNullOrEmpty()) return
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
        } catch (t: Throwable) {
            Logger.w("failed to open url: ${t.message}")
        }
    }
}
