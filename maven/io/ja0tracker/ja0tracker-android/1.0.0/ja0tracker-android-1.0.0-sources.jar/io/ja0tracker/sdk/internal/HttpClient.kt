package io.ja0tracker.sdk.internal

import io.ja0tracker.sdk.Ja0TrackerConfig
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Outcome of a batch POST so the caller (event pump) can decide ack vs. retry.
 */
internal sealed class PostResult {
    /** 2xx — the batch was accepted; the caller acks these event ids. */
    data class Success(val accepted: Int, val duplicates: Int) : PostResult()

    /** 401/400 etc — a permanent client error. Do NOT retry the same body blindly. */
    data class PermanentError(val code: Int, val message: String) : PostResult()

    /** Network / 5xx — transient. Caller retries with exponential backoff. */
    data class TransientError(val message: String) : PostResult()

    /** 429 — buffer/rate limited. Caller waits [retryAfterSeconds] before retrying. */
    data class RateLimited(val retryAfterSeconds: Long) : PostResult()
}

/**
 * Transports event batches to ingest (docs/sdk-contract.md §1, §2).
 *
 * Batch POST `{ingestBaseUrl}/v1/events` with:
 *   X-MT-Key:       <public sdkKey>
 *   X-MT-Timestamp: <unix seconds>
 *   X-MT-Signature: hex(HMAC-SHA256(sdkSecret, "<ts>." + rawBodyBytes))
 *   Content-Type:   application/json
 *
 * The body is signed over the EXACT bytes transmitted (a wrong signature = 401),
 * so we serialize once and sign/send the same array. We intentionally do NOT gzip:
 * the deployed ingest reads the body as raw JSON without content-decoding, so a
 * compressed body would fail both signature verification and JSON parsing.
 *
 * Implemented on HttpURLConnection to avoid a heavy HTTP dependency; called from a
 * coroutine on Dispatchers.IO by the event pump.
 */
internal class HttpClient(private val config: Ja0TrackerConfig) {

    /**
     * Serializes + signs + POSTs a batch. Returns a [PostResult] describing whether
     * the caller should ack, retry, or back off.
     */
    fun postEvents(platform: String, events: List<QueuedEvent>): PostResult {
        if (events.isEmpty()) return PostResult.Success(0, 0)

        val body = encodeBatch(platform, events)
        val ts = System.currentTimeMillis() / 1000L
        val signature = Hmac.signRequest(config.sdkSecret, ts, body)
        val url = "${config.ingestBaseUrl.trimEnd('/')}$EVENTS_PATH"

        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setFixedLengthStreamingMode(body.size)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-MT-Key", config.sdkKey)
                setRequestProperty("X-MT-Timestamp", ts.toString())
                setRequestProperty("X-MT-Signature", signature)
                setRequestProperty("User-Agent", userAgent())
            }
            conn.outputStream.use { it.write(body); it.flush() }

            val code = conn.responseCode
            when {
                code in 200..299 -> {
                    val json = conn.inputStream.bufferedReader().use(BufferedReader::readText)
                    val accepted = extractInt(json, "accepted")
                    val duplicates = extractInt(json, "duplicates")
                    Logger.d("ingest ok: accepted=$accepted duplicates=$duplicates")
                    PostResult.Success(accepted, duplicates)
                }
                code == 429 -> {
                    val retryAfter = conn.getHeaderField("Retry-After")?.toLongOrNull() ?: 5L
                    Logger.w("ingest rate-limited; retry after ${retryAfter}s")
                    PostResult.RateLimited(retryAfter.coerceIn(1L, 300L))
                }
                code == 401 || code == 403 || code == 400 -> {
                    val err = conn.errorStream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
                    Logger.e("ingest permanent error $code: $err")
                    PostResult.PermanentError(code, err)
                }
                code in 500..599 -> {
                    Logger.w("ingest server error $code")
                    PostResult.TransientError("server error $code")
                }
                else -> PostResult.TransientError("unexpected status $code")
            }
        } catch (t: Throwable) {
            // Network failure / timeout — transient, caller retries.
            Logger.w("ingest post failed: ${t.message}")
            PostResult.TransientError(t.message ?: "network error")
        } finally {
            conn?.disconnect()
        }
    }

    /**
     * Serializes the batch envelope EXACTLY as sent (this is what gets signed):
     * {"sdk_key":...,"platform":...,"events":[{event...}]}
     */
    private fun encodeBatch(platform: String, events: List<QueuedEvent>): ByteArray {
        val eventObjs = events.map { e ->
            // LinkedHashMap preserves insertion order for a stable, predictable body.
            val m = LinkedHashMap<String, Any?>()
            m["event_id"] = e.eventId
            m["app_id"] = config.appId
            m["install_id"] = Identity.currentInstallId
            m["name"] = e.name
            m["ts"] = e.timestampSeconds
            if (!e.sessionId.isNullOrEmpty()) m["session_id"] = e.sessionId
            if (e.revenue != null) m["revenue"] = e.revenue
            if (!e.currency.isNullOrEmpty()) m["currency"] = e.currency
            if (!e.paramsJson.isNullOrEmpty()) m["params"] = JsonRaw(e.paramsJson)
            if (!e.installReferrer.isNullOrEmpty()) m["install_referrer"] = e.installReferrer
            if (!e.deviceFp.isNullOrEmpty()) m["device_fp"] = e.deviceFp
            m
        }
        val envelope = LinkedHashMap<String, Any?>()
        envelope["sdk_key"] = config.sdkKey
        envelope["platform"] = platform
        envelope["events"] = eventObjs
        return Json.encode(envelope).toByteArray(Charsets.UTF_8)
    }

    private fun userAgent(): String = "ja0tracker-android/${BuildConstants.VERSION}"

    /** Tiny extractor for the two integer fields in the ingest 200 response. */
    private fun extractInt(json: String, key: String): Int {
        val needle = "\"$key\""
        val at = json.indexOf(needle)
        if (at < 0) return 0
        var i = at + needle.length
        while (i < json.length && (json[i] == ':' || json[i] == ' ')) i++
        val start = i
        while (i < json.length && (json[i].isDigit() || json[i] == '-')) i++
        return json.substring(start, i).toIntOrNull() ?: 0
    }

    companion object {
        const val EVENTS_PATH = "/v1/events"
        private const val CONNECT_TIMEOUT_MS = 10_000
        private const val READ_TIMEOUT_MS = 15_000
    }
}
