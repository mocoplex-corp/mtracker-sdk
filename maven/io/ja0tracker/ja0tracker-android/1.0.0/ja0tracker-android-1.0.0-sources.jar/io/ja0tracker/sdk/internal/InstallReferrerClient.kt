package io.ja0tracker.sdk.internal

import android.content.Context
import com.android.installreferrer.api.InstallReferrerClient as PlayInstallReferrerClient
import com.android.installreferrer.api.InstallReferrerStateListener
import com.android.installreferrer.api.ReferrerDetails
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Recovers the deterministic Play install referrer on first launch
 * (docs/sdk-contract.md §4 "Android 결정적 어트리뷰션").
 *
 * clickd injects a signed click token into the Play Store `referrer` param; the SDK
 * reads it back RAW here (`referrerDetails.installReferrer`) and hands it to the
 * install event's `install_referrer` field unmodified. The backend verifies the
 * HMAC, extracts the click_id, and does the 1:1 match — the SDK never parses the
 * referrer format.
 */
internal data class InstallReferrerResult(
    /** Raw referrer string, passed through verbatim to the backend. */
    val installReferrer: String,
    /** Seconds since epoch — CTIT numerator with [installBeginTimestampSeconds]. */
    val referrerClickTimestampSeconds: Long,
    val installBeginTimestampSeconds: Long,
    val googlePlayInstantParam: Boolean,
)

internal class InstallReferrerClient(private val context: Context) {

    /**
     * Connects to the Play Install Referrer service, reads the referrer, disconnects.
     * Returns null when the referrer is unavailable (Play not installed, feature
     * unsupported, or the service could not be reached after [maxRetries]).
     *
     * The underlying API is one-shot and callback-based; we bridge it to a coroutine
     * and guard against the listener firing more than once. Runs off the main thread
     * (caller invokes on Dispatchers.IO).
     */
    suspend fun fetch(maxRetries: Int = 2): InstallReferrerResult? {
        var attempt = 0
        while (attempt <= maxRetries) {
            val result = connectOnce()
            when (result) {
                is Outcome.Ok -> return result.value
                is Outcome.Unsupported -> return null // no point retrying
                is Outcome.Retryable -> {
                    attempt++
                    if (attempt > maxRetries) return null
                    delay(BASE_BACKOFF_MS * attempt)
                }
            }
        }
        return null
    }

    private sealed class Outcome {
        data class Ok(val value: InstallReferrerResult?) : Outcome()
        object Unsupported : Outcome()
        object Retryable : Outcome()
    }

    private suspend fun connectOnce(): Outcome = suspendCancellableCoroutine { cont ->
        val client = PlayInstallReferrerClient.newBuilder(context.applicationContext).build()
        val resumed = AtomicBoolean(false)

        fun finishAndEnd(outcome: Outcome) {
            // The referrer client must be ended exactly once; guard the listener,
            // which some Play versions can invoke more than once.
            if (resumed.compareAndSet(false, true)) {
                try {
                    client.endConnection()
                } catch (_: Throwable) {
                }
                if (cont.isActive) cont.resume(outcome)
            }
        }

        cont.invokeOnCancellation {
            try {
                client.endConnection()
            } catch (_: Throwable) {
            }
        }

        try {
            client.startConnection(object : InstallReferrerStateListener {
                override fun onInstallReferrerSetupFinished(responseCode: Int) {
                    when (responseCode) {
                        PlayInstallReferrerClient.InstallReferrerResponse.OK -> {
                            val mapped = try {
                                val details: ReferrerDetails = client.installReferrer
                                InstallReferrerResult(
                                    installReferrer = details.installReferrer ?: "",
                                    referrerClickTimestampSeconds = details.referrerClickTimestampSeconds,
                                    installBeginTimestampSeconds = details.installBeginTimestampSeconds,
                                    googlePlayInstantParam = details.googlePlayInstantParam,
                                )
                            } catch (t: Throwable) {
                                Logger.w("install referrer read failed", t)
                                null
                            }
                            finishAndEnd(Outcome.Ok(mapped))
                        }
                        PlayInstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED -> {
                            Logger.d("install referrer: feature not supported")
                            finishAndEnd(Outcome.Unsupported)
                        }
                        PlayInstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE -> {
                            Logger.d("install referrer: service unavailable (retryable)")
                            finishAndEnd(Outcome.Retryable)
                        }
                        else -> {
                            Logger.d("install referrer: response $responseCode")
                            finishAndEnd(Outcome.Retryable)
                        }
                    }
                }

                override fun onInstallReferrerServiceDisconnected() {
                    // Transient disconnect before setup finished — treat as retryable.
                    finishAndEnd(Outcome.Retryable)
                }
            })
        } catch (t: Throwable) {
            Logger.w("install referrer connect threw", t)
            finishAndEnd(Outcome.Retryable)
        }
    }

    companion object {
        private const val BASE_BACKOFF_MS = 500L
    }
}
