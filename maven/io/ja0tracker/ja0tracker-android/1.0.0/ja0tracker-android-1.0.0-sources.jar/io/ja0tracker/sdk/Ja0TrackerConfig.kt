package io.ja0tracker.sdk

/**
 * Log verbosity for the SDK. Maps 1:1 across all four targets. Ordinal order is
 * used for level comparisons (NONE < ERROR < WARN < INFO < DEBUG).
 */
enum class LogLevel { NONE, ERROR, WARN, INFO, DEBUG }

/**
 * Initialization config. Mirrors `Ja0Tracker.initialize({...})` in
 * docs/sdk-contract.md §5.
 *
 * [sdkKey] and [sdkSecret] are issued together when an SDK key is created in the
 * admin dashboard (`/dashboard/mtracker/apps`); the secret is shown once. Both are
 * injected here. NOTE: embedding a shared secret in a client has inherent security
 * limits (documented) — a hardened challenge scheme is a follow-up.
 */
data class Ja0TrackerConfig(
    /** Tenant public SDK key (`public_key`, e.g. `pk_ja0_demo`). Sent as X-MT-Key. */
    val sdkKey: String,

    /** Per-app HMAC secret (`hmac_secret`). Signs the request body. Required. */
    val sdkSecret: String,

    /** App UUID issued by the dashboard, e.g. `00000000-0000-0000-0000-0000000000a1`. */
    val appId: String,

    /** Event ingest base URL. Batch POST {ingestBaseUrl}/v1/events. */
    val ingestBaseUrl: String = DEFAULT_INGEST_BASE_URL,

    /** clickd base URL (click / deferred deep link resolution). */
    val clickdBaseUrl: String = DEFAULT_CLICKD_BASE_URL,

    /**
     * Ad request base URL. The adserver is internal today; leave configurable so
     * the host app can point at the public host when ad slots go live
     * (docs/sdk-contract.md §1, docs/ads.md §3).
     */
    val adBaseUrl: String = DEFAULT_AD_BASE_URL,

    /**
     * App Ops base URL. Remote config, in-app messages, update popups, and push token
     * registration are served by the **api** service, NOT the ingest host:
     *   GET  {appOpsBaseUrl}/v1/appops
     *   POST {appOpsBaseUrl}/v1/push/register
     */
    val appOpsBaseUrl: String = DEFAULT_APPOPS_BASE_URL,

    val logLevel: LogLevel = LogLevel.INFO,

    /**
     * Privacy-first default. When true, deterministic / fingerprint matching stays
     * disabled until [Consent] is granted (docs/sdk-contract.md §4). Analytics
     * custom events are also gated until analytics consent is granted.
     */
    val waitForConsent: Boolean = true,
) {
    companion object {
        const val DEFAULT_INGEST_BASE_URL = "https://ingest-mtracker.ja0.com"
        const val DEFAULT_CLICKD_BASE_URL = "https://go-mtracker.ja0.com"

        // Adserver public host for native ad slots: POST {adBaseUrl}/v1/ad.
        const val DEFAULT_AD_BASE_URL = "https://ad-mtracker.ja0.com"

        // App Ops (remote config / in-app messages / update / push register) are served
        // by the api service, not the ingest host.
        const val DEFAULT_APPOPS_BASE_URL = "https://api-mtracker.ja0.com"
    }
}
