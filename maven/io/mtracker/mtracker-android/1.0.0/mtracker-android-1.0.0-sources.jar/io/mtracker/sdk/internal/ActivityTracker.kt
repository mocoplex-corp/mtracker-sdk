package io.mtracker.sdk.internal

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.lang.ref.WeakReference

/**
 * Tracks the current foreground [Activity] via [Application.ActivityLifecycleCallbacks] so
 * App Ops UI (update popup, message dialog, Play In-App Review) can attach to a live
 * Activity without the host app forwarding anything. Weakly held to avoid leaking.
 */
internal class ActivityTracker : Application.ActivityLifecycleCallbacks {

    private var current: WeakReference<Activity>? = null

    /** The current resumed Activity, or null when the app is backgrounded / mid-transition. */
    val currentActivity: Activity?
        get() = current?.get()

    fun register(app: Application) {
        app.registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityResumed(activity: Activity) {
        current = WeakReference(activity)
    }

    override fun onActivityPaused(activity: Activity) {
        if (current?.get() === activity) current = null
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        if (current?.get() === activity) current = null
    }
}
