package io.mtracker.sdk.internal

import android.content.Context
import android.os.Build
import android.telephony.TelephonyManager
import java.util.Locale
import java.util.TimeZone

/**
 * Device signals collected for probabilistic click<->install matching
 * (docs/sdk-contract.md §4). Collection is CONSENT-GATED: gathered only when the
 * user has granted `attribution` consent. IP is added server-side, not here.
 *
 * Only signals available without extra permissions are collected — no hardware
 * identifiers (no IMEI/serial/ANDROID_ID) so the SDK needs no dangerous permissions.
 */
internal data class DeviceFingerprint(
    val osName: String,
    val osVersion: String,
    val deviceModel: String,
    val deviceManufacturer: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val density: Float,
    val locale: String,
    val timezone: String,
    val carrier: String?,
) {
    /** Serializes to the compact JSON carried in the event `device_fp`/params. */
    fun toJson(): String = Json.encode(
        linkedMapOf(
            "os" to osName,
            "os_version" to osVersion,
            "model" to deviceModel,
            "manufacturer" to deviceManufacturer,
            "screen_w" to screenWidth,
            "screen_h" to screenHeight,
            "density" to density,
            "locale" to locale,
            "timezone" to timezone,
            "carrier" to carrier,
        )
    )
}

internal class Fingerprint(private val context: Context) {

    /**
     * Collects signals only if [attributionConsentGranted]; returns null otherwise
     * so callers never transmit signals without consent (privacy-first).
     */
    fun collect(attributionConsentGranted: Boolean): DeviceFingerprint? {
        if (!attributionConsentGranted) return null
        return try {
            val res = context.resources
            val metrics = res.displayMetrics
            val locale = primaryLocale()
            DeviceFingerprint(
                osName = "android",
                osVersion = Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString(),
                deviceModel = Build.MODEL ?: "",
                deviceManufacturer = Build.MANUFACTURER ?: "",
                screenWidth = metrics.widthPixels,
                screenHeight = metrics.heightPixels,
                density = metrics.density,
                locale = locale,
                timezone = TimeZone.getDefault().id,
                carrier = carrierName(),
            )
        } catch (t: Throwable) {
            Logger.w("fingerprint collection failed", t)
            null
        }
    }

    private fun primaryLocale(): String = try {
        val config = context.resources.configuration
        val locale: Locale =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) config.locales.get(0)
            else @Suppress("DEPRECATION") config.locale
        locale.toLanguageTag()
    } catch (t: Throwable) {
        Locale.getDefault().toLanguageTag()
    }

    private fun carrierName(): String? = try {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        tm?.networkOperatorName?.takeIf { it.isNotBlank() }
    } catch (t: Throwable) {
        null
    }
}
