package io.mtracker.sdk.internal

import io.mtracker.sdk.MTrackerConfig
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Transport for the App Ops surface (docs/appops-contract.md §2, §3).
 *
 * Two endpoints, both on the same public host family as ingest:
 *   - GET  {ingestBase}/v1/appops        — delivery (config/messages/update). PUBLIC, no HMAC.
 *   - POST {ingestBase}/v1/push/register — push token registration. HMAC-signed exactly
 *     like events ([Hmac.signRequest]), reusing the shared signer.
 *
 * Built on HttpURLConnection to match the rest of the Android Core and avoid pulling in a
 * heavy HTTP dependency. Called off the main thread by [AppOpsManager].
 */
internal class AppOpsClient(private val config: MTrackerConfig) {

    /**
     * GET the App Ops payload. Returns the raw parsed JSON object (config/messages/update)
     * or null on any failure — callers treat null as "no ops this cycle".
     *
     * The endpoint is public (tenant resolved from app_id server-side), so NO HMAC headers.
     */
    fun fetch(
        platform: String,
        appVersion: String,
        lang: String,
        installId: String,
        sessionSec: Long,
        sessionCount: Long,
    ): Map<String, Any?>? {
        val q = StringBuilder()
        q.append("app_id=").append(enc(config.appId))
        q.append("&platform=").append(enc(platform))
        q.append("&app_version=").append(enc(appVersion))
        q.append("&lang=").append(enc(lang))
        q.append("&install_id=").append(enc(installId))
        q.append("&session_sec=").append(sessionSec)
        q.append("&session_count=").append(sessionCount)
        val url = "${config.ingestBaseUrl.trimEnd('/')}$APPOPS_PATH?$q"

        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", userAgent())
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                Logger.d("appops fetch HTTP $code")
                return null
            }
            val json = conn.inputStream.bufferedReader().use(BufferedReader::readText)
            JsonParser.parseObject(json)
        } catch (t: Throwable) {
            Logger.d("appops fetch failed: ${t.message}")
            null
        } finally {
            conn?.disconnect()
        }
    }

    /**
     * POST the push token registration (docs/appops-contract.md §3). HMAC-signed like
     * events: X-MT-Key / X-MT-Timestamp / X-MT-Signature over `"<ts>." + rawBody`.
     * Returns true on 2xx.
     */
    fun registerPush(
        platform: String,
        installId: String,
        token: String,
        lang: String,
    ): Boolean {
        val payload = LinkedHashMap<String, Any?>()
        payload["app_id"] = config.appId
        payload["install_id"] = installId
        payload["platform"] = platform
        payload["token"] = token
        payload["lang"] = lang
        val body = Json.encode(payload).toByteArray(Charsets.UTF_8)

        val ts = System.currentTimeMillis() / 1000L
        val signature = Hmac.signRequest(config.sdkSecret, ts, body)
        val url = "${config.ingestBaseUrl.trimEnd('/')}$PUSH_REGISTER_PATH"

        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setFixedLengthStreamingMode(body.size)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-MT-Key", config.sdkKey)
                setRequestProperty("X-MT-Timestamp", ts.toString())
                setRequestProperty("X-MT-Signature", signature)
                setRequestProperty("User-Agent", userAgent())
            }
            conn.outputStream.use { it.write(body); it.flush() }
            val code = conn.responseCode
            val ok = code in 200..299
            if (ok) Logger.d("push token registered") else Logger.w("push register HTTP $code")
            ok
        } catch (t: Throwable) {
            Logger.w("push register failed: ${t.message}")
            false
        } finally {
            conn?.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun userAgent(): String = "mtracker-android/${BuildConstants.VERSION}"

    companion object {
        const val APPOPS_PATH = "/v1/appops"
        const val PUSH_REGISTER_PATH = "/v1/push/register"
        private const val CONNECT_TIMEOUT_MS = 10_000
        private const val READ_TIMEOUT_MS = 15_000
    }
}
