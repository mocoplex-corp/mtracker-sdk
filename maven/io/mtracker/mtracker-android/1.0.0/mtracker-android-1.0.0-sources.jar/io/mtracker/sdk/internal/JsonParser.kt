package io.mtracker.sdk.internal

/**
 * Minimal recursive-descent JSON parser (dependency-free) for the few responses the
 * SDK must read (the ad render contract, docs/ads.md §6). Kept intentionally small;
 * the event ingest path only *writes* JSON, so this covers reads only.
 *
 * Produces a tree of: Map<String, Any?>, List<Any?>, String, Double, Boolean, null.
 * Throws [JsonParseException] on malformed input; callers wrap defensively.
 */
internal class JsonParseException(message: String) : Exception(message)

internal object JsonParser {

    fun parse(input: String): Any? {
        val p = Parser(input)
        val value = p.parseValue()
        p.skipWhitespace()
        if (!p.atEnd()) throw JsonParseException("trailing content at ${p.pos}")
        return value
    }

    /** Convenience: parse and return a Map, or null if the root is not an object. */
    @Suppress("UNCHECKED_CAST")
    fun parseObject(input: String): Map<String, Any?>? =
        try {
            parse(input) as? Map<String, Any?>
        } catch (t: Throwable) {
            null
        }

    private class Parser(private val s: String) {
        var pos = 0

        fun atEnd(): Boolean = pos >= s.length

        fun skipWhitespace() {
            while (pos < s.length) {
                when (s[pos]) {
                    ' ', '\t', '\n', '\r' -> pos++
                    else -> return
                }
            }
        }

        fun parseValue(): Any? {
            skipWhitespace()
            if (atEnd()) throw JsonParseException("unexpected end")
            return when (s[pos]) {
                '{' -> parseObj()
                '[' -> parseArr()
                '"' -> parseString()
                't', 'f' -> parseBool()
                'n' -> parseNull()
                else -> parseNumber()
            }
        }

        private fun parseObj(): Map<String, Any?> {
            expect('{')
            val map = LinkedHashMap<String, Any?>()
            skipWhitespace()
            if (peek() == '}') { pos++; return map }
            while (true) {
                skipWhitespace()
                val key = parseString()
                skipWhitespace()
                expect(':')
                val value = parseValue()
                map[key] = value
                skipWhitespace()
                when (peek()) {
                    ',' -> { pos++; }
                    '}' -> { pos++; return map }
                    else -> throw JsonParseException("expected , or } at $pos")
                }
            }
        }

        private fun parseArr(): List<Any?> {
            expect('[')
            val list = ArrayList<Any?>()
            skipWhitespace()
            if (peek() == ']') { pos++; return list }
            while (true) {
                list.add(parseValue())
                skipWhitespace()
                when (peek()) {
                    ',' -> { pos++; }
                    ']' -> { pos++; return list }
                    else -> throw JsonParseException("expected , or ] at $pos")
                }
            }
        }

        private fun parseString(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonParseException("unterminated string")
                val c = s[pos++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (atEnd()) throw JsonParseException("bad escape")
                        when (val esc = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'n' -> sb.append('\n')
                            't' -> sb.append('\t')
                            'r' -> sb.append('\r')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'u' -> {
                                if (pos + 4 > s.length) throw JsonParseException("bad unicode escape")
                                val hex = s.substring(pos, pos + 4)
                                pos += 4
                                sb.append(hex.toInt(16).toChar())
                            }
                            else -> throw JsonParseException("bad escape \\$esc")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun parseBool(): Boolean {
            return when {
                s.startsWith("true", pos) -> { pos += 4; true }
                s.startsWith("false", pos) -> { pos += 5; false }
                else -> throw JsonParseException("invalid literal at $pos")
            }
        }

        private fun parseNull(): Any? {
            if (s.startsWith("null", pos)) { pos += 4; return null }
            throw JsonParseException("invalid literal at $pos")
        }

        private fun parseNumber(): Double {
            val start = pos
            if (peek() == '-') pos++
            while (!atEnd() && (s[pos].isDigit() || s[pos] == '.' ||
                    s[pos] == 'e' || s[pos] == 'E' || s[pos] == '+' || s[pos] == '-')) {
                pos++
            }
            val token = s.substring(start, pos)
            return token.toDoubleOrNull() ?: throw JsonParseException("invalid number '$token'")
        }

        private fun peek(): Char {
            skipWhitespace()
            if (atEnd()) throw JsonParseException("unexpected end")
            return s[pos]
        }

        private fun expect(c: Char) {
            skipWhitespace()
            if (atEnd() || s[pos] != c) throw JsonParseException("expected '$c' at $pos")
            pos++
        }
    }
}
