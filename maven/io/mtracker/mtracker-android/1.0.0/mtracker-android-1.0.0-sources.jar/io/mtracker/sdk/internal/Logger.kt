package io.mtracker.sdk.internal

import android.util.Log
import io.mtracker.sdk.LogLevel

/**
 * Thin logging shim honoring [LogLevel] (docs/sdk.md §2). All SDK logging goes
 * through here so verbosity is centrally controlled and the SDK stays quiet by
 * default in production apps.
 */
internal object Logger {

    private const val TAG = "MTracker"

    @Volatile
    var level: LogLevel = LogLevel.INFO

    fun d(msg: String) {
        if (level >= LogLevel.DEBUG) Log.d(TAG, msg)
    }

    fun i(msg: String) {
        if (level >= LogLevel.INFO) Log.i(TAG, msg)
    }

    fun w(msg: String, t: Throwable? = null) {
        if (level >= LogLevel.WARN) Log.w(TAG, msg, t)
    }

    fun e(msg: String, t: Throwable? = null) {
        if (level >= LogLevel.ERROR) Log.e(TAG, msg, t)
    }
}
