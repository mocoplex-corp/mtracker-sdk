package io.mtracker.sdk

/**
 * Per-purpose consent flags (GDPR-style). Gates data collection scope
 * (docs/sdk.md §3.4). All default to false — privacy-first.
 *
 * On iOS, [attribution]/[ads] additionally require ATT authorization before
 * fingerprint/clipboard matching runs; see requestTrackingConsent().
 */
data class Consent(
    val analytics: Boolean = false,
    val attribution: Boolean = false,
    val ads: Boolean = false,
)

/**
 * Result of [MTracker.requestTrackingConsent]. On Android this is always
 * [GRANTED] (no ATT concept); on iOS it reflects the ATT authorization status.
 */
enum class TrackingConsentStatus {
    GRANTED,
    DENIED,
    RESTRICTED,
    NOT_DETERMINED,
}
