package io.mtracker.sdk.internal

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Request signing, matching the backend byte-for-byte (docs/sdk-contract.md §2,
 * verified against backend/pkg/authx/hmac.go `VerifyRequest`).
 *
 * The signed message is:  `"<ts>." + <raw body bytes>`
 *   - ts   : the same integer sent in the `X-MT-Timestamp` header (unix seconds)
 *   - body : the exact bytes POSTed as the request body (no re-encoding)
 *
 * Signature = lowercase hex of HMAC-SHA256(hmac_secret, message).
 *
 * A wrong signature = HTTP 401, so nothing here may re-serialize or mutate the
 * body: callers pass the identical byte array they transmit.
 */
internal object Hmac {

    private const val ALGO = "HmacSHA256"

    /**
     * @param secret   the tenant `hmac_secret` (UTF-8) provisioned in MTrackerConfig
     * @param ts       unix seconds, identical to the X-MT-Timestamp header value
     * @param body     the exact request body bytes being POSTed
     * @return lowercase hex HMAC-SHA256 for the X-MT-Signature header
     */
    fun signRequest(secret: String, ts: Long, body: ByteArray): String {
        // message = "<ts>." + body   (backend: strconv.FormatInt(ts,10)+"." then body)
        val prefix = "$ts.".toByteArray(Charsets.UTF_8)
        val message = ByteArray(prefix.size + body.size)
        System.arraycopy(prefix, 0, message, 0, prefix.size)
        System.arraycopy(body, 0, message, prefix.size, body.size)
        return hexHmac(secret.toByteArray(Charsets.UTF_8), message)
    }

    /** HMAC-SHA256 -> lowercase hex. */
    private fun hexHmac(key: ByteArray, message: ByteArray): String {
        val mac = Mac.getInstance(ALGO)
        mac.init(SecretKeySpec(key, ALGO))
        return toHex(mac.doFinal(message))
    }

    private val HEX = "0123456789abcdef".toCharArray()

    private fun toHex(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        var i = 0
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            out[i++] = HEX[v ushr 4]
            out[i++] = HEX[v and 0x0F]
        }
        return String(out)
    }
}
