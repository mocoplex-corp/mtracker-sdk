package io.mtracker.sdk

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import io.mtracker.sdk.ads.MTAds
import io.mtracker.sdk.internal.ActivityTracker
import io.mtracker.sdk.internal.AppOpsManager
import io.mtracker.sdk.internal.EventPump
import io.mtracker.sdk.internal.Fingerprint
import io.mtracker.sdk.internal.HttpClient
import io.mtracker.sdk.internal.Identity
import io.mtracker.sdk.internal.InstallReferrerClient
import io.mtracker.sdk.internal.Json
import io.mtracker.sdk.internal.Logger
import io.mtracker.sdk.internal.QueuedEvent
import io.mtracker.sdk.internal.SecureStore
import io.mtracker.sdk.internal.SessionTracker
import io.mtracker.sdk.internal.SqliteEventQueue
import io.mtracker.sdk.internal.Ulid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Public facade for the mtracker Android SDK.
 *
 * Mirrors the shared cross-platform API (docs/sdk-contract.md §5). All public
 * methods are defensively wrapped so an SDK failure never crashes the host app
 * (docs/sdk.md §5).
 *
 * Usage:
 * ```
 * MTracker.initialize(context, MTrackerConfig(
 *     sdkKey = "pk_ja0_demo",
 *     sdkSecret = "<hmac_secret from dashboard>",
 *     appId = "00000000-0000-0000-0000-0000000000a1",
 * ))
 * MTracker.setConsent(Consent(analytics = true, attribution = true, ads = true))
 * MTracker.onAttribution { data -> /* route by data.source/campaign */ }
 * MTracker.onDeepLink { link -> /* route by link.path/params */ }
 * MTracker.trackEvent("purchase", mapOf("revenue" to 9900, "currency" to "KRW"))
 * ```
 */
object MTracker {

    @Volatile private var initialized = false
    private lateinit var appContext: Context
    private lateinit var config: MTrackerConfig

    @Volatile private var consent: Consent = Consent()

    private lateinit var identity: Identity
    private lateinit var queue: SqliteEventQueue
    private lateinit var pump: EventPump
    private var http: HttpClient? = null
    private var sessionTracker: SessionTracker? = null

    // App Ops (docs/appops-contract.md §2, §5).
    private var store: SecureStore? = null
    private var activityTracker: ActivityTracker? = null
    private var appOps: AppOpsManager? = null

    // Pending App Ops registrations before init completes; replayed once ready.
    private var pendingOnUpdate: ((UpdateInfo) -> Unit)? = null
    private var pendingOnMessage: ((AppMessage, () -> Unit) -> Unit)? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var attributionCallback: ((AttributionData) -> Unit)? = null
    private var deepLinkCallback: ((DeepLinkData) -> Unit)? = null
    private var pendingAttribution: AttributionData? = null
    private var pendingDeepLink: DeepLinkData? = null

    /** Ads accessor — `MTracker.ads.load(slotId)` (docs/sdk-contract.md §5). */
    @JvmStatic
    var ads: MTAds = MTAds.uninitialized()
        private set

    /**
     * Initialize once at app start (Application.onCreate). Bootstraps durable
     * identity, starts session tracking, recovers the Play install referrer on first
     * launch, enqueues the install event, and kicks a flush of any queued events.
     */
    @JvmStatic
    fun initialize(context: Context, config: MTrackerConfig) = safe {
        if (initialized) return@safe
        this.appContext = context.applicationContext
        this.config = config
        Logger.level = config.logLevel

        require(config.sdkKey.isNotBlank()) { "sdkKey is required" }
        require(config.sdkSecret.isNotBlank()) { "sdkSecret is required" }
        require(config.appId.isNotBlank()) { "appId is required" }

        this.identity = Identity(appContext)
        this.store = SecureStore(appContext)
        this.queue = SqliteEventQueue(appContext)
        this.http = HttpClient(config).also {
            this.pump = EventPump(queue, it)
        }
        this.ads = MTAds(
            adBaseUrl = config.adBaseUrl,
            sdkKey = config.sdkKey,
            impressionPost = { url -> fireBeacon(url) },
        )

        // Restore persisted consent so gating survives restarts.
        this.consent = Consent(
            analytics = identity.loadConsentAnalytics(),
            attribution = identity.loadConsentAttribution(),
            ads = identity.loadConsentAds(),
        )

        val launch = identity.bootstrap()

        // Session tracking must register on the main thread (ProcessLifecycleOwner). We also
        // accumulate cumulative foreground time + a session counter into SecureStore; App Ops
        // uses these for the review-prompt gate and the session_sec/session_count params.
        this.sessionTracker = SessionTracker(
            onSessionStart = { sid ->
                enqueue(makeEvent("session_start", sessionId = sid))
                store?.let { s ->
                    s.putLong(SecureStore.KEY_SESSION_COUNT, s.getLong(SecureStore.KEY_SESSION_COUNT, 0L) + 1L)
                }
            },
            onForegroundElapsed = { elapsed ->
                store?.let { s ->
                    s.putLong(
                        SecureStore.KEY_SESSION_SEC_TOTAL,
                        s.getLong(SecureStore.KEY_SESSION_SEC_TOTAL, 0L) + elapsed,
                    )
                    // A newly-crossed review threshold should be checked promptly.
                    appOps?.fetchNow()
                }
            },
        )
        mainHandler.post { safe { sessionTracker?.register() } }

        // App Ops: track the current Activity for default UI + In-App Review, then boot the
        // manager (fetch on init + periodic). getConfig* works from cache before the fetch.
        val app = appContext as? Application
        this.activityTracker = ActivityTracker().also { tracker ->
            app?.let { mainHandler.post { safe { tracker.register(it) } } }
        }
        this.appOps = AppOpsManager(
            context = appContext,
            config = config,
            store = store!!,
            activityTracker = activityTracker!!,
            sessionSec = { cumulativeSessionSec() },
            sessionCount = { store?.getLong(SecureStore.KEY_SESSION_COUNT, 0L) ?: 0L },
            installId = { Identity.currentInstallId },
        ).also { mgr ->
            // Replay any callbacks registered before init.
            pendingOnUpdate?.let { mgr.onUpdateAvailable = it; pendingOnUpdate = null }
            pendingOnMessage?.let { mgr.onMessage = it; pendingOnMessage = null }
            mgr.start()
        }

        initialized = true
        Logger.i("initialized (launch=$launch, first=${identity.isFirstLaunch})")

        // First-launch attribution flow runs off the main thread.
        when (launch) {
            Identity.Launch.INSTALL -> scope.launch { handleFirstLaunch("install") }
            Identity.Launch.REINSTALL -> scope.launch { handleFirstLaunch("reinstall") }
            Identity.Launch.RETURNING -> {
                // Nothing to attribute; just drain anything left from a prior run.
                pump.trigger()
            }
        }
    }

    /**
     * No-op on Android (no ATT). Returns [TrackingConsentStatus.GRANTED] to keep the
     * cross-platform API consistent; on iOS this triggers the ATT prompt.
     */
    @JvmStatic
    suspend fun requestTrackingConsent(): TrackingConsentStatus = TrackingConsentStatus.GRANTED

    /** Sets per-purpose consent flags (docs/sdk-contract.md §4) and persists them. */
    @JvmStatic
    fun setConsent(consent: Consent) = safe {
        if (!initialized) return@safe
        this.consent = consent
        identity.saveConsent(consent.analytics, consent.attribution, consent.ads)
        Logger.d("consent set: analytics=${consent.analytics} attribution=${consent.attribution} ads=${consent.ads}")
    }

    /** Registers the attribution callback; replays a pending result if one arrived early. */
    @JvmStatic
    fun onAttribution(callback: (AttributionData) -> Unit) = safe {
        attributionCallback = callback
        pendingAttribution?.let { deliverOnMain { callback(it) }; pendingAttribution = null }
    }

    /** Registers the deep link callback; replays a pending deferred/live link. */
    @JvmStatic
    fun onDeepLink(callback: (DeepLinkData) -> Unit) = safe {
        deepLinkCallback = callback
        pendingDeepLink?.let { deliverOnMain { callback(it) }; pendingDeepLink = null }
    }

    /**
     * Handle an inbound deep link / App Link intent from the host Activity. Call from
     * Activity.onCreate / onNewIntent. Parses the data URI into [DeepLinkData] and
     * delivers it as a live (non-deferred) link.
     */
    @JvmStatic
    fun handleDeepLink(intent: Intent?) = safe {
        val uri = intent?.data ?: return@safe
        deliverDeepLink(parseDeepLink(uri, isDeferred = false))
    }

    /** Tracks an in-app event (retention/funnel/conversion). */
    @JvmStatic
    @JvmOverloads
    fun trackEvent(name: String, params: Map<String, Any?> = emptyMap()) = safe {
        if (!initialized) return@safe
        // Privacy-first: without analytics consent, drop identified custom events.
        if (config.waitForConsent && !consent.analytics) {
            Logger.d("dropping '$name' — analytics consent not granted")
            return@safe
        }
        // Pull revenue/currency out of params into first-class fields (contract §3).
        val revenue = (params["revenue"] as? Number)?.toDouble()
        val currency = params["currency"] as? String
        val rest = params.filterKeys { it != "revenue" && it != "currency" }
        enqueue(
            makeEvent(
                name = name,
                sessionId = sessionTracker?.currentSessionId,
                revenue = revenue,
                currency = currency,
                params = rest,
            )
        )
    }

    // ---- App Ops: remote config (docs/appops-contract.md §5) ----

    /** Returns a cached remote-config string value, or [default] when absent. */
    @JvmStatic
    @JvmOverloads
    fun getConfigString(key: String, default: String? = null): String? =
        appOps?.getConfigString(key, default) ?: default

    /** Returns a cached remote-config boolean value, or [default] when absent. */
    @JvmStatic
    fun getConfigBool(key: String, default: Boolean): Boolean =
        appOps?.getConfigBool(key, default) ?: default

    /** Returns a cached remote-config integer value, or [default] when absent. */
    @JvmStatic
    fun getConfigInt(key: String, default: Int): Int =
        appOps?.getConfigInt(key, default) ?: default

    /** Returns a cached remote-config value serialized as a JSON string, or null. */
    @JvmStatic
    fun getConfigJson(key: String): String? = appOps?.getConfigJson(key)

    // ---- App Ops: update / message overrides (docs/appops-contract.md §5) ----

    /**
     * Overrides the default update popup. When set, the SDK delivers the localized
     * [UpdateInfo] to [callback] (on the main thread) instead of showing its dialog; the
     * host renders its own UI and opens `storeUrl` for the CTA. Force updates should be
     * rendered as blocking by the host.
     */
    @JvmStatic
    fun onUpdateAvailable(callback: (UpdateInfo) -> Unit) = safe {
        val mgr = appOps
        if (mgr != null) mgr.onUpdateAvailable = callback else pendingOnUpdate = callback
    }

    /**
     * Overrides the default in-app message UI. The SDK delivers the localized [AppMessage]
     * plus a `markShown` completion the host MUST call once it has displayed the message so
     * frequency (once/session/daily) is recorded. Review-type messages are delivered here
     * too when a callback is set (host owns the review UX); otherwise the SDK runs the
     * native Play In-App Review flow.
     */
    @JvmStatic
    fun onMessage(callback: (AppMessage, () -> Unit) -> Unit) = safe {
        val mgr = appOps
        if (mgr != null) mgr.onMessage = callback else pendingOnMessage = callback
    }

    // ---- App Ops: push (docs/appops-contract.md §3) ----

    /**
     * Registers a push token acquired by the host (FCM). The app owns FCM setup; call this
     * with the token from `FirebaseMessaging.getToken()` / `onNewToken`. The token is only
     * sent to `/v1/push/register` (HMAC-signed) once push consent is granted via
     * [setPushConsent]; before that it is queued.
     */
    @JvmStatic
    fun setPushToken(token: String) = safe {
        appOps?.setPushToken(token)
    }

    /** Consent gate for push registration. When granted, any queued token is registered. */
    @JvmStatic
    fun setPushConsent(granted: Boolean) = safe {
        appOps?.setPushConsent(granted)
    }

    // ---- internal ----

    /** Cumulative foreground seconds = persisted total + the in-progress stint. */
    private fun cumulativeSessionSec(): Long {
        val base = store?.getLong(SecureStore.KEY_SESSION_SEC_TOTAL, 0L) ?: 0L
        val live = sessionTracker?.currentForegroundElapsedSec() ?: 0L
        return base + live
    }

    /** Builds a QueuedEvent stamped with a ULID event_id + client unix-seconds ts. */
    private fun makeEvent(
        name: String,
        sessionId: String? = null,
        revenue: Double? = null,
        currency: String? = null,
        params: Map<String, Any?> = emptyMap(),
        installReferrer: String? = null,
        deviceFp: String? = null,
    ): QueuedEvent {
        val paramsJson = if (params.isEmpty()) null else Json.encode(params)
        return QueuedEvent(
            eventId = Ulid.next(),
            name = name,
            timestampSeconds = System.currentTimeMillis() / 1000L,
            sessionId = sessionId,
            revenue = revenue,
            currency = currency,
            paramsJson = paramsJson,
            installReferrer = installReferrer,
            deviceFp = deviceFp,
        )
    }

    private fun enqueue(event: QueuedEvent) {
        queue.enqueue(event)
        pump.trigger()
    }

    /**
     * First-launch attribution: collect the Play install referrer (deterministic) and
     * a consent-gated fingerprint, attach both to the install/reinstall event, enqueue
     * it, then flush. Runs on Dispatchers.IO.
     */
    private suspend fun handleFirstLaunch(eventName: String) {
        var referrer: String? = null
        if (!identity.wasReferrerFetched()) {
            val result = try {
                InstallReferrerClient(appContext).fetch()
            } catch (t: Throwable) {
                Logger.w("install referrer fetch failed", t)
                null
            }
            identity.markReferrerFetched()
            referrer = result?.installReferrer?.takeIf { it.isNotEmpty() }
            if (result != null) {
                Logger.d("install referrer recovered (len=${referrer?.length ?: 0})")
            }
        }

        // Fingerprint only when attribution consent is granted (privacy-first).
        val fp = if (consent.attribution) Fingerprint(appContext).collect(true)?.toJson() else null

        enqueue(
            makeEvent(
                name = eventName,
                installReferrer = referrer,
                deviceFp = fp,
            )
        )
    }

    /** POST an impression/no-op beacon (ads.md §6). Best-effort, off the main thread. */
    private fun fireBeacon(url: String) {
        scope.launch {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    setFixedLengthStreamingMode(0)
                    doOutput = true
                }
                conn.outputStream.use { it.flush() }
                conn.responseCode
                conn.disconnect()
            } catch (t: Throwable) {
                Logger.d("beacon failed: ${t.message}")
            }
        }
    }

    private fun parseDeepLink(uri: Uri, isDeferred: Boolean): DeepLinkData {
        val params = LinkedHashMap<String, String>()
        try {
            for (name in uri.queryParameterNames) {
                uri.getQueryParameter(name)?.let { params[name] = it }
            }
        } catch (_: Throwable) {
        }
        return DeepLinkData(
            path = uri.path,
            params = params,
            url = uri.toString(),
            isDeferred = isDeferred,
        )
    }

    /** Delivered by the internal attribution flow once matching completes. */
    internal fun deliverAttribution(data: AttributionData) = safe {
        val cb = attributionCallback
        if (cb != null) deliverOnMain { cb(data) } else pendingAttribution = data
    }

    internal fun deliverDeepLink(data: DeepLinkData) = safe {
        val cb = deepLinkCallback
        if (cb != null) deliverOnMain { cb(data) } else pendingDeepLink = data
    }

    /** App callbacks are delivered on the main thread for UI safety. */
    private fun deliverOnMain(block: () -> Unit) {
        mainHandler.post { safe(block) }
    }

    /** Defensive wrapper: SDK exceptions must never crash the host app (docs/sdk.md §5). */
    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            Logger.e("swallowed SDK exception", t)
        }
    }
}
