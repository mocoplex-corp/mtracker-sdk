package io.mtracker.sdk.internal

import java.security.SecureRandom

/**
 * Monotonic ULID generator (Universally Unique Lexicographically Sortable ID).
 *
 * A ULID is a 128-bit value rendered as 26 Crockford-Base32 characters:
 *   - 48 bits  : millisecond timestamp (big-endian)
 *   - 80 bits  : cryptographic randomness
 *
 * Used for `event_id` and `install_id` (docs/sdk-contract.md §3). The backend
 * dedups on `event_id`, so uniqueness matters; lexicographic time-ordering is a
 * useful side effect for the event queue.
 *
 * Monotonicity: within the same millisecond the 80-bit random component is
 * incremented rather than regenerated, guaranteeing strictly increasing IDs even
 * under a tight generation loop (avoids collisions and preserves sort order).
 */
internal object Ulid {

    private const val ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ" // Crockford Base32
    private const val TIME_LEN = 10
    private const val RANDOM_LEN = 16
    private const val ULID_LEN = TIME_LEN + RANDOM_LEN

    private val random = SecureRandom()
    private val lock = Any()

    // Last-generated state for monotonicity.
    private var lastTime = 0L
    private val lastRandom = ByteArray(10) // 80 bits

    /** Generates the next ULID string (26 chars). Thread-safe and monotonic. */
    fun next(now: Long = System.currentTimeMillis()): String = synchronized(lock) {
        if (now > lastTime) {
            lastTime = now
            random.nextBytes(lastRandom)
        } else {
            // Same or clock-regressed millisecond: reuse the timestamp and
            // increment the 80-bit random field to stay strictly monotonic.
            incrementRandom(lastRandom)
        }
        encode(lastTime, lastRandom)
    }

    /** Adds 1 to the 80-bit big-endian random field, carrying as needed. */
    private fun incrementRandom(bytes: ByteArray) {
        for (i in bytes.indices.reversed()) {
            val v = (bytes[i].toInt() and 0xFF) + 1
            bytes[i] = (v and 0xFF).toByte()
            if (v <= 0xFF) return // no carry
        }
        // Overflow (astronomically unlikely): reseed to avoid a stuck value.
        random.nextBytes(bytes)
    }

    /** Encodes a 48-bit time + 80-bit random into 26 Crockford-Base32 chars. */
    private fun encode(time: Long, rand: ByteArray): String {
        val out = CharArray(ULID_LEN)

        // 48-bit timestamp -> 10 base32 chars (5 bits each = 50 bits, top 2 unused).
        var t = time and 0xFFFFFFFFFFFFL
        for (i in TIME_LEN - 1 downTo 0) {
            out[i] = ENCODING[(t and 0x1F).toInt()]
            t = t shr 5
        }

        // 80-bit random -> 16 base32 chars. Treat the 10 bytes as a big-endian
        // bitstream and pull 5 bits at a time.
        var bitBuffer = 0
        var bitCount = 0
        var outIdx = TIME_LEN
        for (b in rand) {
            bitBuffer = (bitBuffer shl 8) or (b.toInt() and 0xFF)
            bitCount += 8
            while (bitCount >= 5) {
                bitCount -= 5
                val index = (bitBuffer ushr bitCount) and 0x1F
                out[outIdx++] = ENCODING[index]
            }
        }
        // 80 bits / 5 = exactly 16 chars, no remainder to flush.
        return String(out)
    }
}
