package io.mtracker.sdk.internal

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * A single tracked event, enqueued for batch delivery to ingest. Mirrors the
 * event object in docs/sdk-contract.md §3.
 *
 * `eventId` is a ULID for server-side idempotent dedup (§4). `timestampSeconds` is
 * the client unix-seconds value serialized as `ts`. Optional fields are omitted
 * from the wire payload when null/blank so the JSON matches the backend's
 * `omitempty` shape.
 */
internal data class QueuedEvent(
    val eventId: String,
    val name: String,
    val timestampSeconds: Long,
    val sessionId: String? = null,
    val revenue: Double? = null,
    val currency: String? = null,
    /** Pre-serialized JSON object string for `params`, or null. */
    val paramsJson: String? = null,
    /** Android Play referrer raw string — only on the first-launch install event. */
    val installReferrer: String? = null,
    /** Fingerprint JSON attached to the install event (consent-gated). */
    val deviceFp: String? = null,
)

/**
 * Offline-durable event queue contract. Events survive app restarts and are flushed
 * to ingest in batches with exponential-backoff retry (docs/sdk-contract.md §4).
 */
internal interface EventQueue {
    fun enqueue(event: QueuedEvent)
    /** Peek up to [max] oldest events for a batch flush without removing them. */
    fun peekBatch(max: Int): List<QueuedEvent>
    /** Remove events that were successfully delivered (or are permanently dead). */
    fun ack(eventIds: List<String>)
    fun size(): Int
}

/**
 * SQLite-backed durable queue (docs/sdk-contract.md §4 — "no loss across restart").
 *
 * A single append-only table keyed by the ULID event_id (also the dedup key, so
 * inserts are idempotent via INSERT OR IGNORE). Rows are drained oldest-first and
 * removed only after the server acks the batch. All access is synchronized; SQLite
 * itself is safe for concurrent readers but we keep writes serialized for clarity.
 */
internal class SqliteEventQueue(context: Context) : EventQueue {

    private val helper = Helper(context.applicationContext)
    private val lock = Any()

    override fun enqueue(event: QueuedEvent) {
        val values = ContentValues().apply {
            put(COL_EVENT_ID, event.eventId)
            put(COL_NAME, event.name)
            put(COL_TS, event.timestampSeconds)
            put(COL_SESSION_ID, event.sessionId)
            if (event.revenue != null) put(COL_REVENUE, event.revenue) else putNull(COL_REVENUE)
            put(COL_CURRENCY, event.currency)
            put(COL_PARAMS, event.paramsJson)
            put(COL_INSTALL_REFERRER, event.installReferrer)
            put(COL_DEVICE_FP, event.deviceFp)
        }
        synchronized(lock) {
            // OR IGNORE: event_id is unique, so a re-enqueue is a no-op (idempotent).
            helper.writableDatabase.insertWithOnConflict(
                TABLE, null, values, SQLiteDatabase.CONFLICT_IGNORE,
            )
        }
    }

    override fun peekBatch(max: Int): List<QueuedEvent> = synchronized(lock) {
        val out = ArrayList<QueuedEvent>(max)
        helper.readableDatabase.query(
            TABLE, null, null, null, null, null, "$COL_ROWID ASC", max.toString(),
        ).use { c ->
            val idxEventId = c.getColumnIndexOrThrow(COL_EVENT_ID)
            val idxName = c.getColumnIndexOrThrow(COL_NAME)
            val idxTs = c.getColumnIndexOrThrow(COL_TS)
            val idxSession = c.getColumnIndexOrThrow(COL_SESSION_ID)
            val idxRevenue = c.getColumnIndexOrThrow(COL_REVENUE)
            val idxCurrency = c.getColumnIndexOrThrow(COL_CURRENCY)
            val idxParams = c.getColumnIndexOrThrow(COL_PARAMS)
            val idxReferrer = c.getColumnIndexOrThrow(COL_INSTALL_REFERRER)
            val idxFp = c.getColumnIndexOrThrow(COL_DEVICE_FP)
            while (c.moveToNext()) {
                out.add(
                    QueuedEvent(
                        eventId = c.getString(idxEventId),
                        name = c.getString(idxName),
                        timestampSeconds = c.getLong(idxTs),
                        sessionId = c.getStringOrNull(idxSession),
                        revenue = if (c.isNull(idxRevenue)) null else c.getDouble(idxRevenue),
                        currency = c.getStringOrNull(idxCurrency),
                        paramsJson = c.getStringOrNull(idxParams),
                        installReferrer = c.getStringOrNull(idxReferrer),
                        deviceFp = c.getStringOrNull(idxFp),
                    )
                )
            }
        }
        out
    }

    override fun ack(eventIds: List<String>) {
        if (eventIds.isEmpty()) return
        synchronized(lock) {
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                val stmt = db.compileStatement("DELETE FROM $TABLE WHERE $COL_EVENT_ID = ?")
                for (id in eventIds) {
                    stmt.bindString(1, id)
                    stmt.executeUpdateDelete()
                    stmt.clearBindings()
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    override fun size(): Int = synchronized(lock) {
        helper.readableDatabase.query(
            TABLE, arrayOf("COUNT(*)"), null, null, null, null, null,
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    private fun android.database.Cursor.getStringOrNull(idx: Int): String? =
        if (isNull(idx)) null else getString(idx)

    private class Helper(context: Context) :
        SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE $TABLE (
                  $COL_ROWID INTEGER PRIMARY KEY AUTOINCREMENT,
                  $COL_EVENT_ID TEXT UNIQUE NOT NULL,
                  $COL_NAME TEXT NOT NULL,
                  $COL_TS INTEGER NOT NULL,
                  $COL_SESSION_ID TEXT,
                  $COL_REVENUE REAL,
                  $COL_CURRENCY TEXT,
                  $COL_PARAMS TEXT,
                  $COL_INSTALL_REFERRER TEXT,
                  $COL_DEVICE_FP TEXT
                )
                """.trimIndent()
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Schema is additive-only; drop-and-recreate is acceptable for an
            // ephemeral outbound queue (unsent events are best-effort telemetry).
            db.execSQL("DROP TABLE IF EXISTS $TABLE")
            onCreate(db)
        }
    }

    companion object {
        private const val DB_NAME = "mtracker_events.db"
        private const val DB_VERSION = 1
        private const val TABLE = "events"
        private const val COL_ROWID = "rowid_"
        private const val COL_EVENT_ID = "event_id"
        private const val COL_NAME = "name"
        private const val COL_TS = "ts"
        private const val COL_SESSION_ID = "session_id"
        private const val COL_REVENUE = "revenue"
        private const val COL_CURRENCY = "currency"
        private const val COL_PARAMS = "params"
        private const val COL_INSTALL_REFERRER = "install_referrer"
        private const val COL_DEVICE_FP = "device_fp"
    }
}
