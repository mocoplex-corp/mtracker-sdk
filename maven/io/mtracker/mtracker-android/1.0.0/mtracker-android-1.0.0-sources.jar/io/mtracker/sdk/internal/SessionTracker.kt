package io.mtracker.sdk.internal

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner

/**
 * Foreground/background session boundaries (docs/sdk-contract.md §4).
 *
 * A `session_start` event is emitted each time the app enters the foreground, EXCEPT
 * when returning from a short background excursion (< [sessionTimeoutMs]) which keeps
 * the same session. The session-open event is the baseline signal for retention
 * cohorts (backend `retention_daily` rollup).
 *
 * Wires into androidx.lifecycle.ProcessLifecycleOwner so the host app never has to
 * forward lifecycle callbacks manually. Registration happens on the main thread.
 */
internal class SessionTracker(
    private val sessionTimeoutMs: Long = 30_000L,
    private val onSessionStart: (sessionId: String) -> Unit = {},
    /**
     * Persists accumulated foreground time on each background transition. Reports the
     * delta (seconds) since the last foreground entry so the App Ops layer can gate the
     * review prompt on cumulative session time (docs/appops-contract.md §5). Optional so
     * the tracker keeps working standalone.
     */
    private val onForegroundElapsed: (elapsedSec: Long) -> Unit = {},
) : DefaultLifecycleObserver {

    @Volatile
    var currentSessionId: String? = null
        private set

    private var lastBackgroundedAt: Long = 0L
    private var startedOnce = false
    /** Wall-clock ms at which the current foreground stint began (for elapsed accounting). */
    private var foregroundStartedAt: Long = 0L

    /**
     * Observe the process lifecycle. Must be called on the main thread
     * (ProcessLifecycleOwner requires it); [MTracker] posts this to the main looper.
     */
    fun register() {
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    // --- ProcessLifecycleOwner callbacks -------------------------------------

    override fun onStart(owner: LifecycleOwner) {
        onForeground()
    }

    override fun onStop(owner: LifecycleOwner) {
        onBackground()
    }

    /**
     * Opens a new session unless a session is already active and the app was only
     * backgrounded briefly. Emits `session_start` for a genuinely new session.
     */
    fun onForeground(nowMs: Long = System.currentTimeMillis()) {
        foregroundStartedAt = nowMs
        val existing = currentSessionId
        if (existing != null && startedOnce && nowMs - lastBackgroundedAt < sessionTimeoutMs) {
            return // short background: same session resumed
        }
        val id = Ulid.next(nowMs)
        currentSessionId = id
        startedOnce = true
        onSessionStart(id)
    }

    fun onBackground(nowMs: Long = System.currentTimeMillis()) {
        lastBackgroundedAt = nowMs
        // Accumulate the just-completed foreground stint (seconds).
        val start = foregroundStartedAt
        if (start > 0L && nowMs > start) {
            onForegroundElapsed((nowMs - start) / 1000L)
        }
        foregroundStartedAt = 0L
    }

    /**
     * Foreground seconds elapsed in the CURRENT (still-open) stint, if any. Lets the App
     * Ops layer include in-progress time when it fetches without waiting for a background
     * transition. Returns 0 when backgrounded.
     */
    fun currentForegroundElapsedSec(nowMs: Long = System.currentTimeMillis()): Long {
        val start = foregroundStartedAt
        return if (start > 0L && nowMs > start) (nowMs - start) / 1000L else 0L
    }
}
