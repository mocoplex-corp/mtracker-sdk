package io.mtracker.sdk.ads

import io.mtracker.sdk.internal.Json
import io.mtracker.sdk.internal.JsonParser
import io.mtracker.sdk.internal.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ads accessor, reached via `MTracker.ads` (docs/sdk-contract.md §5, docs/ads.md).
 * Requests a native ad by slot ID; the adserver decides which ad fills the slot and
 * returns the render contract from ads.md §6.
 *
 * The adserver is internal today, so [adBaseUrl] is configurable
 * (MTrackerConfig.adBaseUrl) — point it at the public host once ad slots go live.
 */
class MTAds internal constructor(
    private val adBaseUrl: String,
    private val sdkKey: String,
    /** Fires an impression beacon (POST) — injected by MTracker so ads reuse its HTTP path. */
    internal val impressionPost: (url: String) -> Unit = {},
    private val enabled: Boolean = true,
) {
    /**
     * Loads a native ad for [slotId]. POSTs the ad request (ads.md §3) and parses the
     * winning ad's assets + tracking URLs (ads.md §6), or returns null on no-fill
     * (HTTP 204) / error. Runs the network call off the main thread.
     *
     * @param slotId the dashboard-issued slot key/id
     * @param userId stable pseudonymous id used for frequency capping (optional)
     * @param context arbitrary placement-context signals forwarded to the adserver
     */
    @JvmOverloads
    suspend fun load(
        slotId: String,
        userId: String? = null,
        context: Map<String, Any?> = emptyMap(),
    ): NativeAd? {
        if (!enabled) {
            Logger.w("ads.load called before MTracker.initialize")
            return null
        }
        return withContext(Dispatchers.IO) { request(slotId, userId, context) }
    }

    private fun request(slotId: String, userId: String?, ctx: Map<String, Any?>): NativeAd? {
        val url = "${adBaseUrl.trimEnd('/')}$AD_PATH"
        val bodyMap = LinkedHashMap<String, Any?>().apply {
            // Accept slot by SDK-facing key or id; adserver resolves either.
            put("slot_id", slotId)
            put("slot_key", slotId)
            put("platform", "android")
            if (!userId.isNullOrEmpty()) put("user_id", userId)
            if (ctx.isNotEmpty()) put("context", ctx)
        }
        val body = Json.encode(bodyMap).toByteArray(Charsets.UTF_8)

        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 10000
                doOutput = true
                setFixedLengthStreamingMode(body.size)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-MT-Key", sdkKey)
            }
            conn.outputStream.use { it.write(body); it.flush() }
            when (val code = conn.responseCode) {
                204 -> {
                    Logger.d("ad no-fill for slot $slotId")
                    null
                }
                in 200..299 -> {
                    val json = conn.inputStream.bufferedReader().use(BufferedReader::readText)
                    parseAd(slotId, json)
                }
                else -> {
                    Logger.w("ad request failed ($code) for slot $slotId")
                    null
                }
            }
        } catch (t: Throwable) {
            Logger.w("ad request error for slot $slotId: ${t.message}")
            null
        } finally {
            conn?.disconnect()
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseAd(slotId: String, json: String): NativeAd? {
        val root = JsonParser.parseObject(json) ?: return null
        val assets = root["assets"] as? Map<String, Any?> ?: emptyMap()
        val tracking = root["tracking"] as? Map<String, Any?> ?: emptyMap()
        val mediaMap = assets["media"] as? Map<String, Any?>

        val media = mediaMap?.let {
            val type = (it["type"] as? String)?.lowercase()
            val mediaUrl = it["url"] as? String
            if (!mediaUrl.isNullOrEmpty()) {
                NativeAdMedia(
                    type = if (type == "video") NativeAdMedia.MediaType.VIDEO
                    else NativeAdMedia.MediaType.IMAGE,
                    url = mediaUrl,
                )
            } else null
        }

        val impressionUrls: List<String> = (tracking["impression"] as? List<*>)
            ?.mapNotNull { it as? String } ?: emptyList()
        val clickUrl = tracking["click"] as? String ?: ""
        val vt = tracking["viewableThreshold"] as? Map<String, Any?>
        val threshold = ViewableThreshold(
            pixels = (vt?.get("pixels") as? Number)?.toDouble() ?: 0.5,
            ms = (vt?.get("ms") as? Number)?.toLong() ?: 1000L,
        )

        return NativeAd(
            slotId = root["slotId"] as? String ?: slotId,
            adId = root["adId"] as? String ?: "",
            format = root["format"] as? String ?: "native",
            assets = NativeAdAssets(
                headline = assets["headline"] as? String,
                body = assets["body"] as? String,
                advertiser = assets["advertiser"] as? String,
                cta = assets["cta"] as? String,
                iconUrl = assets["icon"] as? String,
                media = media,
                rating = (assets["rating"] as? Number)?.toDouble(),
            ),
            tracking = NativeAdTracking(
                impressionUrls = impressionUrls,
                clickUrl = clickUrl,
                viewableThreshold = threshold,
            ),
        )
    }

    companion object {
        private const val AD_PATH = "/v1/ad"

        /** A disabled placeholder used before initialize() so `MTracker.ads` is non-null. */
        internal fun uninitialized(): MTAds =
            MTAds(adBaseUrl = "", sdkKey = "", impressionPost = {}, enabled = false)
    }
}
