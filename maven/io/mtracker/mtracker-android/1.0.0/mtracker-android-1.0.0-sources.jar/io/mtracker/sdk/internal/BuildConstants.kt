package io.mtracker.sdk.internal

import io.mtracker.sdk.BuildConfig

/**
 * Central access to build-time constants. Wraps the generated [BuildConfig] so the
 * rest of the SDK does not depend on the exact generated symbol and stays testable.
 */
internal object BuildConstants {
    /** SDK semantic version, injected via `buildConfigField` in build.gradle.kts. */
    val VERSION: String = runCatching { BuildConfig.SDK_VERSION }.getOrDefault("0.0.0")
}
