package io.mtracker.sdk

/**
 * Deferred deep link context restored on first launch after install, or a direct
 * deep link when the app is already installed (docs/attribution.md §5).
 *
 * Deliver to [MTracker.onDeepLink]; the app routes on [path] + [params].
 */
data class DeepLinkData(
    /** e.g. "/product/123" — the `$deeplink_path` from link creation. */
    val path: String?,
    /** Custom link parameters (contentId, referrer, promoCode, ...). */
    val params: Map<String, String> = emptyMap(),
    /** Full original URL if available. */
    val url: String? = null,
    /** True when restored after a fresh install (deferred), false for a live click. */
    val isDeferred: Boolean = false,
)
