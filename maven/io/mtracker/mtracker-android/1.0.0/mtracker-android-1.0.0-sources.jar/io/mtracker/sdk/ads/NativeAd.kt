package io.mtracker.sdk.ads

/**
 * Native ad asset model — mirrors the server rendering contract in docs/ads.md §6.
 * The app renders these assets in its own design system; the SDK owns only the
 * impression/click beacons and click routing.
 */
data class NativeAdMedia(
    val type: MediaType,
    val url: String,
) {
    enum class MediaType { IMAGE, VIDEO }
}

data class NativeAdAssets(
    val headline: String?,
    val body: String?,
    val advertiser: String?,
    val cta: String?,
    val iconUrl: String?,
    val media: NativeAdMedia?,
    val rating: Double?,
)

/**
 * Viewability threshold for a valid impression (docs/ads.md §4, §6).
 */
data class ViewableThreshold(
    val pixels: Double = 0.5,
    val ms: Long = 1000,
)

data class NativeAdTracking(
    val impressionUrls: List<String>,
    val clickUrl: String,
    val viewableThreshold: ViewableThreshold,
)

/**
 * A loaded native ad returned by [MTAds.load]. Rendered via [MTNativeAdView] or a
 * fully-custom app component that reads [assets] directly (docs/ads.md §6).
 */
data class NativeAd(
    val slotId: String,
    val adId: String,
    val format: String,          // "native" | "banner" | "native-video"
    val assets: NativeAdAssets,
    val tracking: NativeAdTracking,
)
