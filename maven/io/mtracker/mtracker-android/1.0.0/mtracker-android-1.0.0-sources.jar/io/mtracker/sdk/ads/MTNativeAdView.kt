package io.mtracker.sdk.ads

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import io.mtracker.sdk.internal.Logger
import kotlin.math.roundToInt

/**
 * Default View that renders a [NativeAd]'s assets and fires viewability-gated
 * impression + click beacons (docs/ads.md §6).
 *
 * Apps may render assets entirely themselves (read [NativeAd.assets] directly); this
 * template is the "quick start" path. The SDK owns ONLY the impression beacon (fired
 * once the ad meets the viewability threshold) and click routing through clickd
 * (go-mtracker.ja0.com/ad/...), which joins the attribution pipeline — the closed
 * loop in ads.md §4.
 *
 * Impression firing is delegated to [MTAds.impressionPost] (POST), so ads reuse the
 * SDK's HTTP path; clicks open the tracking URL via ACTION_VIEW.
 */
class MTNativeAdView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    private var ad: NativeAd? = null
    private var impressionFired = false
    private var beaconPoster: ((String) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private var visibleSince: Long = 0L

    // Template views (built lazily on first bind).
    private var iconView: ImageView? = null
    private var headlineView: TextView? = null
    private var bodyView: TextView? = null
    private var advertiserView: TextView? = null
    private var ctaView: TextView? = null

    /**
     * Binds an ad and builds/updates the default template.
     *
     * @param ad the loaded native ad
     * @param impressionPoster optional custom impression beacon poster. When null the
     *   View POSTs the beacon itself (see [defaultBeacon]), so most callers just pass
     *   the ad. Kept overridable so the View has no singleton dependency and stays
     *   unit-testable.
     */
    @JvmOverloads
    fun bind(ad: NativeAd, impressionPoster: ((String) -> Unit)? = null) {
        this.ad = ad
        this.beaconPoster = impressionPoster
        this.impressionFired = false
        this.visibleSince = 0L

        if (headlineView == null) buildTemplate()

        headlineView?.text = ad.assets.headline.orEmpty()
        bodyView?.text = ad.assets.body.orEmpty()
        advertiserView?.text = ad.assets.advertiser.orEmpty()
        ctaView?.text = (ad.assets.cta ?: "Learn more")
        // Icon/media are remote images: the host app supplies an image loader via a
        // fully-custom renderer. The default template shows text + CTA reliably; see
        // README "Custom rendering" for wiring Glide/Coil to iconView/media.
        setOnClickListener { fireClick() }

        startViewabilityWatch()
    }

    private fun buildTemplate() {
        val dp = { v: Int -> TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).roundToInt() }

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }

        iconView = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) }
            setBackgroundColor(Color.parseColor("#EEEEEE"))
        }
        row.addView(iconView)

        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        headlineView = TextView(context).apply {
            setTextColor(Color.parseColor("#111111"))
            textSize = 15f
            maxLines = 1
        }
        bodyView = TextView(context).apply {
            setTextColor(Color.parseColor("#555555"))
            textSize = 13f
            maxLines = 2
        }
        advertiserView = TextView(context).apply {
            setTextColor(Color.parseColor("#999999"))
            textSize = 11f
            maxLines = 1
        }
        textCol.addView(headlineView)
        textCol.addView(bodyView)
        textCol.addView(advertiserView)
        row.addView(textCol)

        ctaView = TextView(context).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#3D5AFE"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { leftMargin = dp(12) }
        }
        row.addView(ctaView)

        addView(row)
    }

    // --- Viewability ---------------------------------------------------------

    private val viewabilityListener = ViewTreeObserver.OnScrollChangedListener { checkViewability() }
    private val globalLayoutListener = ViewTreeObserver.OnGlobalLayoutListener { checkViewability() }

    private fun startViewabilityWatch() {
        if (impressionFired) return
        viewTreeObserver.addOnScrollChangedListener(viewabilityListener)
        viewTreeObserver.addOnGlobalLayoutListener(globalLayoutListener)
        post { checkViewability() }
    }

    private fun stopViewabilityWatch() {
        viewTreeObserver.removeOnScrollChangedListener(viewabilityListener)
        @Suppress("DEPRECATION")
        viewTreeObserver.removeOnGlobalLayoutListener(globalLayoutListener)
        mainHandler.removeCallbacks(impressionRunnable)
    }

    private val impressionRunnable = Runnable {
        // Fire only if still viewable after the dwell time.
        if (!impressionFired && isViewable()) fireImpression()
    }

    /**
     * Checks the viewability threshold (default 50% pixels visible). When first met,
     * schedules the impression to fire after the required dwell (default 1000ms).
     */
    private fun checkViewability() {
        val ad = ad ?: return
        if (impressionFired) return
        if (isViewable(ad.tracking.viewableThreshold.pixels)) {
            if (visibleSince == 0L) {
                visibleSince = System.currentTimeMillis()
                mainHandler.postDelayed(impressionRunnable, ad.tracking.viewableThreshold.ms)
            }
        } else {
            // Left the viewport before dwell completed — reset the timer.
            visibleSince = 0L
            mainHandler.removeCallbacks(impressionRunnable)
        }
    }

    private fun isViewable(minFraction: Double = 0.5): Boolean {
        if (!isShown || width == 0 || height == 0) return false
        val rect = Rect()
        val visible = getGlobalVisibleRect(rect)
        if (!visible) return false
        val visibleArea = rect.width().toLong() * rect.height().toLong()
        val totalArea = width.toLong() * height.toLong()
        if (totalArea == 0L) return false
        return visibleArea.toDouble() / totalArea.toDouble() >= minFraction
    }

    private fun fireImpression() {
        val ad = ad ?: return
        if (impressionFired) return
        impressionFired = true
        stopViewabilityWatch()
        val poster = beaconPoster
        for (url in ad.tracking.impressionUrls) {
            if (url.isEmpty()) continue
            try {
                if (poster != null) poster(url) else defaultBeacon(url)
            } catch (t: Throwable) {
                Logger.d("impression beacon failed: ${t.message}")
            }
        }
        Logger.d("ad impression fired (${ad.adId})")
    }

    private fun fireClick() {
        val ad = ad ?: return
        val clickUrl = ad.tracking.clickUrl
        if (clickUrl.isEmpty()) return
        try {
            // clickd resolves /ad/{token}, records the ad_click, and 302s to the store —
            // opening in the browser lets Play/App Store handle the install (ads.md §4).
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(clickUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (t: Throwable) {
            Logger.w("ad click routing failed", t)
        }
    }

    /** Fallback POST beacon if no poster was supplied (best-effort, off the UI thread). */
    private fun defaultBeacon(url: String) {
        Thread {
            var conn: java.net.HttpURLConnection? = null
            try {
                conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    doOutput = true
                    setFixedLengthStreamingMode(0)
                }
                conn.outputStream.use { it.flush() }
                conn.responseCode
            } catch (t: Throwable) {
                Logger.d("beacon failed: ${t.message}")
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    override fun onDetachedFromWindow() {
        stopViewabilityWatch()
        super.onDetachedFromWindow()
    }
}
