package io.mtracker.sdk

/**
 * How an install was matched to a click. Ordered by precedence
 * (docs/attribution.md §7): deterministic > probabilistic > aggregate > organic.
 */
enum class AttributionConfidence {
    DETERMINISTIC,   // Install Referrer (Android) / clipboard token (iOS)
    PROBABILISTIC,   // fingerprint window match (has a confidence score)
    AGGREGATE,       // SKAN / AAK campaign-level
    ORGANIC,         // no match
}

/**
 * Attribution result delivered to [MTracker.onAttribution].
 * Represents the campaign/source that drove the install (last-touch by default).
 */
data class AttributionData(
    val source: String?,          // e.g. "meta", "google", "tiktok", "organic"
    val campaign: String?,
    val network: String?,
    val clickId: String?,
    val confidence: AttributionConfidence,
    /** 0.0–1.0, meaningful only for PROBABILISTIC matches. */
    val confidenceScore: Double? = null,
    /** Raw extra fields the backend returned (adgroup, creative, etc.). */
    val raw: Map<String, String> = emptyMap(),
)
