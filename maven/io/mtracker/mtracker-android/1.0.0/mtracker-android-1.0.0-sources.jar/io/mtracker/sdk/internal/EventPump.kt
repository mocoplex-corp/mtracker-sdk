package io.mtracker.sdk.internal

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.min
import kotlin.math.pow

/**
 * Drains the durable [EventQueue] to ingest via [HttpClient] with batching and
 * exponential-backoff retry (docs/sdk-contract.md §4).
 *
 * A single-flight [flush] coalesces concurrent trigger requests; on transient
 * failure it schedules a delayed retry with exponential backoff (capped), and on a
 * 429 it honors the server's Retry-After. Successfully-accepted events (and
 * server-side duplicates, which are also "done") are acked and removed. Permanent
 * 4xx errors drop the offending batch so a poison event can't wedge the queue.
 */
internal class EventPump(
    private val queue: EventQueue,
    private val http: HttpClient,
    private val platform: String = "android",
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {
    private val flushMutex = Mutex()

    @Volatile
    private var retryJob: Job? = null

    /** Request a flush. Coalesced: safe to call after every enqueue. */
    fun trigger() {
        scope.launch { flush() }
    }

    /**
     * Attempts to drain the queue batch-by-batch. Returns when the queue is empty,
     * a batch cannot be sent (schedules a backoff retry), or a rate limit is hit.
     */
    private suspend fun flush(attempt: Int = 0) {
        // Single-flight: if a flush is already running, let it finish; it will drain
        // everything currently queued including anything just enqueued.
        if (!flushMutex.tryLock()) return
        try {
            var backoffAttempt = attempt
            while (true) {
                val batch = queue.peekBatch(BATCH_SIZE)
                if (batch.isEmpty()) {
                    backoffAttempt = 0
                    return
                }
                when (val result = http.postEvents(platform, batch)) {
                    is PostResult.Success -> {
                        // Both accepted and duplicate events are permanently handled.
                        queue.ack(batch.map { it.eventId })
                        backoffAttempt = 0
                        // Loop to drain the next batch.
                    }
                    is PostResult.PermanentError -> {
                        // Poison batch (e.g. malformed) — drop it to avoid wedging the
                        // queue. A 401 usually means bad credentials: dropping avoids an
                        // infinite hot loop; misconfig surfaces in logs.
                        Logger.e("dropping batch on permanent error ${result.code}: ${result.message}")
                        queue.ack(batch.map { it.eventId })
                    }
                    is PostResult.RateLimited -> {
                        scheduleRetry(result.retryAfterSeconds * 1000L, backoffAttempt)
                        return
                    }
                    is PostResult.TransientError -> {
                        scheduleRetry(backoffMillis(backoffAttempt), backoffAttempt + 1)
                        return
                    }
                }
            }
        } finally {
            flushMutex.unlock()
        }
    }

    private fun scheduleRetry(delayMs: Long, nextAttempt: Int) {
        // Only one pending retry at a time.
        if (retryJob?.isActive == true) return
        retryJob = scope.launch {
            delay(delayMs)
            flush(nextAttempt)
        }
    }

    private fun backoffMillis(attempt: Int): Long {
        val exp = BASE_BACKOFF_MS * 2.0.pow(attempt.toDouble())
        val capped = min(exp, MAX_BACKOFF_MS.toDouble()).toLong()
        // Full jitter to avoid retry storms across many installs.
        return (capped / 2) + (Math.random() * (capped / 2)).toLong()
    }

    companion object {
        private const val BATCH_SIZE = 50
        private const val BASE_BACKOFF_MS = 1_000L
        private const val MAX_BACKOFF_MS = 5 * 60 * 1000L // 5 minutes
    }
}
