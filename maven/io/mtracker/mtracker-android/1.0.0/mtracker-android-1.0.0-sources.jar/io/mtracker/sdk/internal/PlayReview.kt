package io.mtracker.sdk.internal

import android.app.Activity
import com.google.android.play.core.review.ReviewManagerFactory

/**
 * Play In-App Review launcher (docs/appops-contract.md §5). Wraps
 * `com.google.android.play:review(-ktx)` so the review flow uses Google's native,
 * quota-limited in-app review card. On any failure (API missing, quota exhausted, no
 * dialog shown) the [onUnavailable] callback runs so the caller can fall back to a custom
 * dialog + store link.
 *
 * The Play API never guarantees the card is actually shown, so success here means "the
 * flow completed" — matching Google's contract. We treat that as the review having been
 * attempted for frequency purposes.
 */
internal object PlayReview {

    fun request(activity: Activity, onCompleted: () -> Unit, onUnavailable: () -> Unit) {
        try {
            val manager = ReviewManagerFactory.create(activity)
            val requestFlow = manager.requestReviewFlow()
            requestFlow.addOnCompleteListener { request ->
                if (request.isSuccessful) {
                    val reviewInfo = request.result
                    val flow = manager.launchReviewFlow(activity, reviewInfo)
                    flow.addOnCompleteListener {
                        // Whether or not the card appeared, the flow finished — done.
                        onCompleted()
                    }
                } else {
                    Logger.d("play review request failed: ${request.exception?.message}")
                    onUnavailable()
                }
            }
        } catch (t: Throwable) {
            // ReviewManagerFactory can throw if the Play review lib isn't on the classpath.
            Logger.d("play review unavailable: ${t.message}")
            onUnavailable()
        }
    }
}
