package io.mtracker.sdk.internal

import android.content.Context
import android.content.pm.PackageManager

/**
 * Owns the SDK's durable identity + first-launch determination
 * (docs/sdk-contract.md §4).
 *
 * On first ever launch we mint a ULID `install_id`, persist it in [SecureStore],
 * and mark first-launch done. Because EncryptedSharedPreferences lives in the
 * app's private storage, an app *reinstall* clears it — so a missing install_id on
 * a device that has clearly run the app before is treated as a reinstall.
 *
 * `install_id` is exposed statically (via [currentInstallId]) so the wire encoder
 * can stamp every event without threading it through every call.
 */
internal class Identity(context: Context) {

    private val store = SecureStore(context)
    private val appContext = context.applicationContext

    /** Set once at initialize(); read by the batch encoder. */
    var installId: String = ""
        private set

    /** True only for the very first launch after a fresh install. */
    var isFirstLaunch: Boolean = false
        private set

    /**
     * Loads or creates the persistent identity. Returns the launch classification
     * so the caller emits the correct first-launch event (`install`/`reinstall`).
     */
    fun bootstrap(): Launch {
        val existing = store.getString(SecureStore.KEY_INSTALL_ID)
        val firstLaunchDone = store.getBoolean(SecureStore.KEY_FIRST_LAUNCH_DONE, false)

        return if (existing.isNullOrEmpty() || !firstLaunchDone) {
            // No persisted identity: first launch (fresh install or reinstall).
            val id = Ulid.next()
            installId = id
            isFirstLaunch = true
            store.putString(SecureStore.KEY_INSTALL_ID, id)
            store.putBoolean(SecureStore.KEY_FIRST_LAUNCH_DONE, true)
            store.putString(SecureStore.KEY_APP_VERSION, currentAppVersion())
            currentInstallId = id

            // Reinstall heuristic: the OS reports a first-install timestamp that
            // differs from the last-update timestamp, indicating the app existed
            // before. A fresh install has firstInstall == lastUpdate.
            val launch = if (looksLikeReinstall()) Launch.REINSTALL else Launch.INSTALL
            Logger.i("first launch classified as $launch (install_id=$id)")
            launch
        } else {
            installId = existing
            isFirstLaunch = false
            currentInstallId = existing

            // Persist the current app version so version upgrades can be detected
            // by higher layers if needed (not an install event).
            val stored = store.getString(SecureStore.KEY_APP_VERSION)
            val now = currentAppVersion()
            if (stored != now) store.putString(SecureStore.KEY_APP_VERSION, now)

            Launch.RETURNING
        }
    }

    fun markReferrerFetched() {
        store.putBoolean(SecureStore.KEY_REFERRER_FETCHED, true)
    }

    fun wasReferrerFetched(): Boolean =
        store.getBoolean(SecureStore.KEY_REFERRER_FETCHED, false)

    fun saveConsent(analytics: Boolean, attribution: Boolean, ads: Boolean) {
        store.putBoolean(SecureStore.KEY_CONSENT_ANALYTICS, analytics)
        store.putBoolean(SecureStore.KEY_CONSENT_ATTRIBUTION, attribution)
        store.putBoolean(SecureStore.KEY_CONSENT_ADS, ads)
    }

    fun loadConsentAnalytics(): Boolean = store.getBoolean(SecureStore.KEY_CONSENT_ANALYTICS, false)
    fun loadConsentAttribution(): Boolean = store.getBoolean(SecureStore.KEY_CONSENT_ATTRIBUTION, false)
    fun loadConsentAds(): Boolean = store.getBoolean(SecureStore.KEY_CONSENT_ADS, false)

    private fun looksLikeReinstall(): Boolean = try {
        val pm = appContext.packageManager
        val info = pm.getPackageInfo(appContext.packageName, 0)
        // firstInstallTime vs lastUpdateTime: on a reinstall these usually differ.
        info.lastUpdateTime > info.firstInstallTime
    } catch (t: PackageManager.NameNotFoundException) {
        false
    } catch (t: Throwable) {
        false
    }

    private fun currentAppVersion(): String = try {
        val pm = appContext.packageManager
        val info = pm.getPackageInfo(appContext.packageName, 0)
        info.versionName ?: ""
    } catch (t: Throwable) {
        ""
    }

    /** Launch classification returned by [bootstrap]. */
    enum class Launch {
        INSTALL,     // fresh first launch -> emit "install"
        REINSTALL,   // first launch but device shows prior presence -> emit "reinstall"
        RETURNING,   // identity already persisted -> no install event
    }

    companion object {
        /** Snapshot of the current install_id for the wire encoder. */
        @Volatile
        var currentInstallId: String = ""
            internal set
    }
}
