# mtracker-react-native

React Native SDK for mtracker — mobile attribution, in-app events, deferred deep links,
and native ad slots. A **thin TurboModule + Fabric wrapper** over the native iOS/Android
cores (`sdk/ios`, `sdk/android`). Works on the New Architecture (TurboModule + Fabric) and
the legacy bridge.

> The TypeScript API, codegen specs, and the native iOS/Android bridges are all
> implemented and delegate to the shared cores. Nothing is compiled in this scaffolding
> environment (no RN/native toolchain) — build it in your app.

> **Build & release:** see [`docs/sdk-build-release.md`](../../docs/sdk-build-release.md).
> Official distribution + integration guide: <https://mtracker.ja0.com/sdk>.

## Install

```sh
npm install mtracker-react-native

# iOS: install pods (autolinks the bridge + the MTracker Core pod)
cd ios && pod install

# Android: no step needed — autolinked via react-native.config.js.
# Rebuild the app (./gradlew or `npx react-native run-android`).
```

### Client build steps

- **Android** — the bridge is a Gradle module autolinked from `react-native.config.js`.
  It depends on the Core AAR `io.mtracker:mtracker-android:1.0.0`; publish `sdk/android` to
  a Maven repo the app can resolve (or `includeBuild("sdk/android")` in the monorepo).
  Set `newArchEnabled=true` in `android/gradle.properties` for the TurboModule path
  (the legacy path also works).
- **iOS** — `pod install` links the bridge podspec, which `s.dependency "MTracker"` pulls
  in the Core. Ship an `MTracker.podspec` (XCFramework/source) from `sdk/ios`, or add the
  MTracker SwiftPM package to the Xcode project. Set `RCT_NEW_ARCH_ENABLED=1` (via
  `pod install` env or Podfile) for Fabric + TurboModule.
- **Expo** — add the config plugin (below); run `npx expo prebuild` then build.

Expo: add the config plugin (auto-injects ATT usage string, deep-link domains, privacy
manifest):

```json
{
  "plugins": [
    ["mtracker-react-native", {
      "attUsageDescription": "We use your data to measure ad performance.",
      "deepLinkDomains": ["go-mtracker.ja0.com"]
    }]
  ]
}
```

## Usage

```tsx
import MTracker, { MTNativeAd } from 'mtracker-react-native';

// 1. Initialize once at app start
MTracker.initialize({ sdkKey: 'APP_SDK_KEY', sdkSecret: 'APP_SDK_SECRET', appId: 'APP_UUID' });

// 2. Consent (iOS shows the ATT prompt; Android resolves to "granted")
const status = await MTracker.requestTrackingConsent();
MTracker.setConsent({ analytics: true, attribution: true, ads: true });

// 3. Attribution + deferred deep link callbacks (return an unsubscribe fn)
const off1 = MTracker.onAttribution((data) => {
  // data.source, data.campaign, data.confidence
});
const off2 = MTracker.onDeepLink((link) => {
  // route by link.path + link.params
});

// 4. In-app events
MTracker.trackEvent('purchase', { revenue: 9900, currency: 'KRW', itemId: '...' });

// 5. Native ads (docs/ads.md)
const ad = await MTracker.ads.load('home_feed_slot');       // imperative
// or render the component:
<MTNativeAd slotId="home_feed_slot" onAdClicked={(e) => console.log(e.adId)} />
```

## Architecture

- `src/index.tsx` — public TS facade + types (mirrors Android/iOS/Flutter).
- `src/NativeMtracker.ts` — TurboModule codegen spec.
- `src/MTNativeAdViewNativeComponent.ts` — Fabric native component codegen spec.
- `src/MTNativeAd.tsx` — ergonomic React wrapper for the native ad view.
- `android/` — Kotlin TurboModule + Fabric ViewManager delegating to `io.mtracker.sdk`
  (see `android/README.md`).
- `ios/` — Swift shim + ObjC++ TurboModule + Fabric component delegating to `MTracker`
  (see `ios/README.md`).
- `react-native.config.js` — autolinking (Android package + iOS podspec).
- `app.plugin.js` — Expo config plugin (ATT usage string, associated domains, Android
  deep-link intent filters).

## Backend endpoints

- Ingest: `https://ingest-mtracker.ja0.com` (batch `POST /v1/events`, JSON + SDK key + HMAC)
- clickd / deep links: `https://go-mtracker.ja0.com`

Override via `MTracker.initialize({ ingestBaseUrl, clickdBaseUrl })`.

## Remaining pre-release tasks

- Publish the native cores so the app can resolve them: an `MTracker.podspec`
  (XCFramework/source) from `sdk/ios`, and the `io.mtracker:mtracker-android` AAR from
  `sdk/android`.
- `TODO(core)`: expose impression/click listeners on the Core `MTNativeAdView` so
  `onAdImpression` / `onAdClicked` reach JS (beacons already fire in the Core).
- Wire `react-native-builder-bob` to produce `lib/` for npm publishing (the `build`
  script is currently a placeholder).
