# mtracker-react-native — Android bridge

Thin TurboModule + Fabric bridge exposing the native Android Core (`sdk/android`, the
`io.ja0tracker.sdk` AAR) to React Native. It **delegates** every call to the Core — it never
reimplements HMAC signing, the event queue, attribution, sessions, or ad rendering.

## Files

- `build.gradle` — depends on `io.ja0tracker:ja0tracker-android` (the shared Core AAR) plus the
  React Native runtime and coroutines. Splits `src/newarch` vs `src/oldarch` by
  `newArchEnabled`.
- `src/main/java/io/mtracker/reactnative/MtrackerModuleImpl.kt` — all bridging logic;
  maps JS <-> Core (`initialize`, `requestTrackingConsent`, `setConsent`, `trackEvent`,
  `loadAd`) and re-emits the Core's `onAttribution` / `onDeepLink` callbacks to JS via
  `RCTDeviceEventEmitter` under `mtracker:onAttribution` / `mtracker:onDeepLink`.
- `src/newarch/.../MtrackerModule.kt` — TurboModule subclass of the codegen
  `NativeMtrackerSpec`; forwards to the impl.
- `src/oldarch/.../MtrackerModule.kt` — legacy bridge module with the same surface.
- `src/main/.../MtrackerPackage.kt` — `TurboReactPackage` registering the module + the
  Fabric ad ViewManager.
- `src/main/.../MTNativeAdViewManager.kt` + `AdEvents.kt` — `SimpleViewManager` wrapping
  `io.ja0tracker.sdk.ads.MTNativeAdView`; loads the ad by `slotId` via `Ja0Tracker.ads.load`,
  binds it, and bubbles `onAdLoaded/onAdFailed/onAdImpression/onAdClicked` to JS.

## How it wires to the Core

`MtrackerModuleImpl` calls `io.ja0tracker.sdk.Ja0Tracker` directly:
`initialize(context, Ja0TrackerConfig(...))`, `setConsent(Consent(...))`,
`requestTrackingConsent()` (bridged from a `suspend fun` onto a coroutine),
`trackEvent(name, params)`, and `Ja0Tracker.ads.load(slotId)` (also `suspend`). Callbacks are
registered once against the Core and re-emitted to JS.

## Notes

- Autolinked via `react-native.config.js` (`packageInstance: new MtrackerPackage()`).
- The Core AAR coordinate is `io.ja0tracker:ja0tracker-android:1.0.0`. In the monorepo you can
  `includeBuild("sdk/android")` and substitute the module instead of publishing.
- Deep-link intent filters for `go-mtracker.ja0.com` are injected by `app.plugin.js` (Expo)
  or added to the host `AndroidManifest.xml` by the app.
- `TODO(core)`: `MTNativeAdView` does not yet expose impression/click listeners, so
  `onAdImpression` / `onAdClicked` are not surfaced to JS until the Core adds them. Beacons
  still fire inside the Core view (closed-loop tracking is unaffected).
