package io.mtracker.reactnative

import com.facebook.react.TurboReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfo
import com.facebook.react.module.model.ReactModuleInfoProvider
import com.facebook.react.uimanager.ViewManager

/**
 * React Native package registration. Autolinked via
 * `react-native.config.js` -> android.packageInstance, or discovered automatically by the
 * RN Gradle plugin.
 *
 * Provides both the TurboModule (`MtrackerModule`) and the Fabric native ad ViewManager
 * (`MTNativeAdViewManager`). Works under the New Architecture (TurboReactPackage resolves
 * the module by name) and the legacy bridge (getModule fallback).
 */
class MtrackerPackage : TurboReactPackage() {

    override fun getModule(name: String, reactContext: ReactApplicationContext): NativeModule? =
        if (name == MtrackerModuleImpl.NAME) MtrackerModule(reactContext) else null

    override fun getReactModuleInfoProvider(): ReactModuleInfoProvider = ReactModuleInfoProvider {
        mapOf(
            MtrackerModuleImpl.NAME to ReactModuleInfo(
                MtrackerModuleImpl.NAME,        // name
                MtrackerModuleImpl.NAME,        // className
                false,                          // canOverrideExistingModule
                false,                          // needsEagerInit
                false,                          // isCxxModule
                true,                           // isTurboModule
            )
        )
    }

    /** Fabric / legacy ViewManager for `<MTNativeAd>`. */
    override fun createViewManagers(
        reactContext: ReactApplicationContext,
    ): List<ViewManager<*, *>> = listOf(MTNativeAdViewManager())
}
