package io.mtracker.reactnative

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.events.Event

/**
 * Fabric/legacy view events for `<MTNativeAd>`, matching the DirectEventHandlers in
 * `src/MTNativeAdViewNativeComponent.ts`.
 */

class OnAdLoaded(viewTag: Int, private val adId: String) : Event<OnAdLoaded>(viewTag) {
    override fun getEventName() = "onAdLoaded"
    override fun getEventData(): WritableMap = Arguments.createMap().apply { putString("adId", adId) }
}

class OnAdFailed(viewTag: Int, private val reason: String) : Event<OnAdFailed>(viewTag) {
    override fun getEventName() = "onAdFailed"
    override fun getEventData(): WritableMap = Arguments.createMap().apply { putString("reason", reason) }
}

class OnAdImpression(viewTag: Int, private val adId: String) : Event<OnAdImpression>(viewTag) {
    override fun getEventName() = "onAdImpression"
    override fun getEventData(): WritableMap = Arguments.createMap().apply { putString("adId", adId) }
}

class OnAdClicked(viewTag: Int, private val adId: String) : Event<OnAdClicked>(viewTag) {
    override fun getEventName() = "onAdClicked"
    override fun getEventData(): WritableMap = Arguments.createMap().apply { putString("adId", adId) }
}
