/**
 * Expo config plugin for mtracker-react-native.
 *
 * Injects the native config the SDK needs (docs/sdk.md §4 "Expo 지원"):
 *   - iOS  : NSUserTrackingUsageDescription (ATT prompt) + associated domains
 *            (applinks:<domain>) for Universal-Link deep links.
 *   - Android: a VIEW intent-filter (autoVerify) on the main activity for each
 *            deep-link domain, so App Links reach MTracker.handleDeepLink.
 *
 * The native Core deps are pulled in by autolinking (the Android Gradle module + the iOS
 * podspec), so this plugin only manages manifest/plist entries — it does not add the SDK.
 *
 * Usage (app.json / app.config.js):
 *   {
 *     "plugins": [
 *       ["mtracker-react-native", {
 *         "attUsageDescription": "We use your data to measure ad performance.",
 *         "deepLinkDomains": ["go-mtracker.ja0.com"]
 *       }]
 *     ]
 *   }
 */

const {
  withInfoPlist,
  withEntitlementsPlist,
  withAndroidManifest,
  AndroidConfig,
} = require('@expo/config-plugins');

const DEFAULT_ATT_USAGE =
  'This app uses your data to attribute installs and measure ad performance.';
const DEFAULT_DEEP_LINK_DOMAINS = ['go-mtracker.ja0.com'];

/** iOS: ATT usage string. */
function withAttUsage(config, attUsage) {
  return withInfoPlist(config, (c) => {
    c.modResults.NSUserTrackingUsageDescription =
      c.modResults.NSUserTrackingUsageDescription || attUsage;
    return c;
  });
}

/** iOS: associated domains (applinks:) for Universal-Link deep links. */
function withAssociatedDomains(config, domains) {
  return withEntitlementsPlist(config, (c) => {
    const key = 'com.apple.developer.associated-domains';
    const existing = new Set(c.modResults[key] || []);
    for (const d of domains) existing.add(`applinks:${d}`);
    c.modResults[key] = Array.from(existing);
    return c;
  });
}

/** Android: a VIEW intent-filter (autoVerify) per deep-link domain on the main activity. */
function withAndroidDeepLinks(config, domains) {
  return withAndroidManifest(config, (c) => {
    const app = AndroidConfig.Manifest.getMainApplicationOrThrow(c.modResults);
    const activity = AndroidConfig.Manifest.getMainActivityOrThrow(c.modResults);

    activity['intent-filter'] = activity['intent-filter'] || [];
    for (const host of domains) {
      const alreadyPresent = activity['intent-filter'].some((f) =>
        (f.data || []).some((d) => d.$ && d.$['android:host'] === host)
      );
      if (alreadyPresent) continue;

      activity['intent-filter'].push({
        $: { 'android:autoVerify': 'true' },
        action: [{ $: { 'android:name': 'android.intent.action.VIEW' } }],
        category: [
          { $: { 'android:name': 'android.intent.category.DEFAULT' } },
          { $: { 'android:name': 'android.intent.category.BROWSABLE' } },
        ],
        data: [{ $: { 'android:scheme': 'https', 'android:host': host } }],
      });
    }

    // Keep a reference to the app node (no-op mutation guard for older manifests).
    void app;
    return c;
  });
}

/**
 * @param {object} config  Expo config object.
 * @param {{ attUsageDescription?: string, deepLinkDomains?: string[] }} [props]
 */
function withMtracker(config, props = {}) {
  const attUsage = props.attUsageDescription || DEFAULT_ATT_USAGE;
  const domains =
    props.deepLinkDomains && props.deepLinkDomains.length
      ? props.deepLinkDomains
      : DEFAULT_DEEP_LINK_DOMAINS;

  config = withAttUsage(config, attUsage);
  config = withAssociatedDomains(config, domains);
  config = withAndroidDeepLinks(config, domains);

  // Note: the sdk/ios PrivacyInfo.xcprivacy is bundled by the MTracker pod/SPM resources,
  // so no extra copy step is needed here.
  return config;
}

module.exports = withMtracker;
