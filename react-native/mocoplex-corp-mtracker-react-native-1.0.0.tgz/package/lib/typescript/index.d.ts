export { default as MTNativeAd } from './MTNativeAd';
export type { MTNativeAdProps } from './MTNativeAd';
export type LogLevel = 'none' | 'error' | 'warn' | 'info' | 'debug';
export interface MTrackerConfig {
    /** Tenant SDK public key issued by the mtracker dashboard. Required (SDK contract §5). */
    sdkKey: string;
    /**
     * Tenant HMAC secret issued alongside `sdkKey` (SDK contract §2). Used by the native
     * Core to sign event batches; embedded-secret limits are documented in the contract.
     * Required — the native cores refuse to initialize without it.
     */
    sdkSecret: string;
    /** App id (UUID) issued by the dashboard (SDK contract §3). Required. */
    appId: string;
    logLevel?: LogLevel;
    /** Privacy-first default: gate deterministic/fingerprint matching on consent. */
    waitForConsent?: boolean;
    /** Configurable backend base URLs (override the live defaults). */
    ingestBaseUrl?: string;
    clickdBaseUrl?: string;
    /** Native ad request host (adserver is internal today; override when it goes public). */
    adBaseUrl?: string;
}
export interface Consent {
    analytics: boolean;
    attribution: boolean;
    ads: boolean;
}
export type TrackingConsentStatus = 'granted' | 'denied' | 'restricted' | 'notDetermined';
export type AttributionConfidence = 'deterministic' | 'probabilistic' | 'aggregate' | 'organic';
export interface AttributionData {
    source: string | null;
    campaign: string | null;
    network: string | null;
    clickId: string | null;
    confidence: AttributionConfidence;
    /** 0.0–1.0, meaningful only for probabilistic matches. */
    confidenceScore?: number | null;
    raw?: Record<string, string>;
}
export interface DeepLinkData {
    path: string | null;
    params: Record<string, string>;
    url?: string | null;
    isDeferred: boolean;
}
export interface NativeAdMedia {
    type: 'image' | 'video';
    url: string;
}
export interface NativeAdAssets {
    headline?: string | null;
    body?: string | null;
    advertiser?: string | null;
    cta?: string | null;
    iconUrl?: string | null;
    media?: NativeAdMedia | null;
    rating?: number | null;
}
export interface NativeAdTracking {
    impressionUrls: string[];
    clickUrl: string;
    viewableThreshold: {
        pixels: number;
        ms: number;
    };
}
export interface NativeAd {
    slotId: string;
    adId: string;
    format: string;
    assets: NativeAdAssets;
    tracking: NativeAdTracking;
}
/** Server-driven version-update prompt (already localized to the device language). */
export interface UpdateInfo {
    available: boolean;
    force: boolean;
    latestVersion: string | null;
    storeUrl: string | null;
    title: string | null;
    body: string | null;
}
export type AppMessageType = 'update' | 'announcement' | 'review' | 'custom';
export type AppMessageFrequency = 'once' | 'session' | 'daily' | 'always';
/** In-app message / announcement / review prompt (already localized). */
export interface AppMessage {
    id: string;
    type: AppMessageType;
    priority: number;
    title: string | null;
    body: string | null;
    ctaText: string | null;
    ctaUrl: string | null;
    imageUrl: string | null;
    force: boolean;
    minSessionSec: number;
    frequency: AppMessageFrequency;
}
export type Unsubscribe = () => void;
export declare const MTracker: {
    /** Initialize once at app start. */
    initialize(config: MTrackerConfig): void;
    /** iOS: triggers the ATT prompt. Android: resolves to "granted" (no-op). */
    requestTrackingConsent(): Promise<TrackingConsentStatus>;
    setConsent(consent: Consent): void;
    /** Register the attribution callback. Returns an unsubscribe fn. */
    onAttribution(cb: (data: AttributionData) => void): Unsubscribe;
    /** Register the deferred/live deep link callback. Returns an unsubscribe fn. */
    onDeepLink(cb: (data: DeepLinkData) => void): Unsubscribe;
    trackEvent(name: string, params?: Record<string, unknown>): void;
    /** Returns a cached remote-config string, or `defaultValue` when absent. */
    getConfigString(key: string, defaultValue?: string | null): Promise<string | null>;
    /** Returns a cached remote-config boolean, or `defaultValue` when absent. */
    getConfigBool(key: string, defaultValue: boolean): Promise<boolean>;
    /** Returns a cached remote-config integer, or `defaultValue` when absent. */
    getConfigInt(key: string, defaultValue: number): Promise<number>;
    /** Returns a cached remote-config value parsed from JSON (object/array/scalar), or null. */
    getConfigJson<T = unknown>(key: string): Promise<T | null>;
    /**
     * Override the default update popup. Receives the localized UpdateInfo; render your own
     * UI and open `storeUrl` for the CTA (make `force` updates blocking). Returns unsubscribe.
     */
    onUpdateAvailable(cb: (data: UpdateInfo) => void): Unsubscribe;
    /**
     * Override the default in-app message UI. Receives the localized AppMessage. The native
     * side records frequency on delivery; render your own UI (announcement/custom) or handle
     * review as you wish. Returns unsubscribe.
     */
    onMessage(cb: (data: AppMessage) => void): Unsubscribe;
    /** Consent gate for push registration; queued tokens are sent once granted. */
    setPushConsent(granted: boolean): void;
    /** Register an FCM/APNs token (host owns push setup). POSTed once consent is granted. */
    setPushToken(token: string): void;
    ads: {
        /** Load a native ad by slot ID (docs/ads.md). Resolves null on no-fill. */
        load(slotId: string): Promise<NativeAd | null>;
    };
};
export default MTracker;
//# sourceMappingURL=index.d.ts.map