import type { HostComponent, ViewProps } from 'react-native';
import codegenNativeComponent from 'react-native/Libraries/Utilities/codegenNativeComponent';
import type {
  DirectEventHandler,
  WithDefault,
} from 'react-native/Libraries/Types/CodegenTypes';

/**
 * Fabric native component spec (New Architecture / codegen) for the native ad view.
 *
 * The native side renders the ad assets and fires viewability-gated impression + click
 * beacons, wrapping `MTNativeAdView` in `sdk/ios` / `sdk/android` (docs/ads.md §6).
 *
 * Codegen constraint: props must be primitives/objects only. `slotId` drives the load;
 * events surface impression/click to JS.
 *
 * TODO(native): register this component name ("MTNativeAdView") on both platforms and
 * bridge to the native ad view.
 */
export interface NativeProps extends ViewProps {
  slotId: string;
  /** Optional: render the built-in default template vs. app-custom (docs/ads.md §6). */
  useDefaultTemplate?: WithDefault<boolean, true>;
  onAdLoaded?: DirectEventHandler<Readonly<{ adId: string }>>;
  onAdFailed?: DirectEventHandler<Readonly<{ reason: string }>>;
  onAdImpression?: DirectEventHandler<Readonly<{ adId: string }>>;
  onAdClicked?: DirectEventHandler<Readonly<{ adId: string }>>;
}

export default codegenNativeComponent<NativeProps>(
  'MTNativeAdView'
) as HostComponent<NativeProps>;
