require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

# mtracker-react-native — iOS podspec.
#
# Thin TurboModule + Fabric bridge to the shared iOS Core (the `MTracker` Swift package /
# XCFramework at sdk/ios). This pod DELEGATES to the Core; it does not reimplement it.
Pod::Spec.new do |s|
  s.name         = "mtracker-react-native"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.license      = package["license"]
  s.authors      = { "mocoplex" => "dev@mocoplex.com" }
  s.homepage     = "https://github.com/mocoplex/mtracker"
  s.platforms    = { :ios => "15.0" }
  s.source       = { :git => "https://github.com/mocoplex/mtracker.git", :tag => "#{s.version}" }

  # ObjC++ TurboModule (.mm/.h), the Swift shim + ad container, and the Fabric component.
  s.source_files = "ios/**/*.{h,m,mm,swift}"

  # Swift/ObjC interop: the .mm files import "mtracker_react_native-Swift.h".
  s.pod_target_xcconfig = {
    "DEFINES_MODULE" => "YES",
    "SWIFT_OBJC_INTERFACE_HEADER_NAME" => "mtracker_react_native-Swift.h",
    "CLANG_CXX_LANGUAGE_STANDARD" => "c++17"
  }

  # React Native New Architecture (TurboModule + Fabric) dependencies + codegen wiring.
  # This helper (RN >= 0.71) also enables the New Arch compiler flags when the app opts in.
  install_modules_dependencies(s) if respond_to?(:install_modules_dependencies)

  # The shared native Core — DELEGATE, never duplicate.
  #
  # The Core is a Swift Package (sdk/ios). Distribute it to CocoaPods consumers as an
  # `MTracker.podspec` (XCFramework or source pod) and declare the dependency here:
  s.dependency "MTracker"   # from sdk/ios — provides `import MTracker`

  # If the app prefers SwiftPM for the Core instead of a pod, remove the line above and add
  # the MTracker package to the app's Xcode project; the bridge's `import MTracker` resolves
  # against it either way.
end
