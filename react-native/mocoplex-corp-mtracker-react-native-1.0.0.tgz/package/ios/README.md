# mtracker-react-native — iOS bridge

Thin TurboModule + Fabric bridge exposing the native iOS Core (`sdk/ios`, the `Ja0Tracker`
Swift package / XCFramework) to React Native. It **delegates** to the Core — it never
reimplements HMAC signing, the event queue, attribution, sessions, or ad rendering.

## Files

- `MtrackerImpl.swift` — `@objc` Swift shim that imports `Ja0Tracker` and forwards every
  call to `Ja0Tracker.shared`. Maps Core models to `NSDictionary` for the ObjC++ boundary and
  installs the Core's `onAttribution` / `onDeepLink` callbacks.
- `Mtracker.h` / `Mtracker.mm` — the TurboModule. Subclasses `RCTEventEmitter` (so the JS
  `NativeEventEmitter` receives `mtracker:onAttribution` / `mtracker:onDeepLink`), exports
  `initialize / requestTrackingConsent / setConsent / trackEvent / loadAd`, and provides the
  `getTurboModule:` hook under the New Architecture (`NativeMtrackerSpecJSI`).
- `MTNativeAdContainerView.swift` — a UIView wrapping the Core's `MTNativeAdView`; loads the
  ad via `Ja0Tracker.shared.ads.load(slotId)`, binds it, and exposes `RCTDirectEventBlock`
  props for the ad lifecycle.
- `MTNativeAdViewManager.mm` — legacy `RCTViewManager` for `<MTNativeAd>`.
- `MTNativeAdComponentView.mm` — Fabric host component (New Architecture) for the same
  JS component, forwarding events through the codegen event emitter.

## How it wires to the Core

`import Ja0TrackerSDK` in `MtrackerImpl.swift`, then direct calls to `Ja0Tracker.shared`
(`initialize(_:)`, `setConsent(_:)`, `requestTrackingConsent()` via `Task`,
`trackEvent(_:_:)`, `ads.load(_:)`). The Core is linked as the `Ja0TrackerSDK` pod/SPM package
declared in `mtracker-react-native.podspec` — never duplicated here.

## Notes

- The podspec sets `SWIFT_OBJC_INTERFACE_HEADER_NAME=mtracker_react_native-Swift.h`; the
  `.mm` files import that generated header to reach the Swift shim.
- `PrivacyInfo.xcprivacy` ships as a resource of the `Ja0TrackerSDK` pod/SPM package; the host
  app's `NSUserTrackingUsageDescription` is injected by `app.plugin.js` (Expo) or set by
  the app.
- `TODO(core)`: `MTNativeAdView` does not yet expose impression/click listeners, so
  `onAdImpression` / `onAdClicked` are not surfaced to JS until the Core adds them.
