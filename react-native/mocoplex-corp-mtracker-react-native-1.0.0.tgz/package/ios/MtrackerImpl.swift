import Foundation
import Ja0TrackerSDK

/// ObjC-visible Swift shim that DELEGATES to the shared iOS Core (`Ja0Tracker` Swift
/// package). The RN TurboModule (`Mtracker.mm`) is ObjC++ and cannot call the Core's
/// pure-Swift API directly, so this `@objc` class is the seam. It never reimplements
/// Core logic — every method forwards to `Ja0Tracker.shared`.
///
/// Values cross the ObjC boundary as Foundation types (NSDictionary / NSString / blocks)
/// so the `.mm` can hand them straight to React Native's bridging types.
@objc(MtrackerImpl)
public final class MtrackerImpl: NSObject {

    @objc public static let shared = MtrackerImpl()

    /// Callbacks the `.mm` installs; invoked when the Core delivers attribution/deep links.
    @objc public var onAttribution: ((NSDictionary) -> Void)?
    @objc public var onDeepLink: ((NSDictionary) -> Void)?
    /// App Ops: invoked when the Core delivers a version-update prompt / in-app message.
    @objc public var onUpdateAvailable: ((NSDictionary) -> Void)?
    @objc public var onMessage: ((NSDictionary) -> Void)?

    private var listenersWired = false

    /// config: sdkKey, sdkSecret, appId, logLevel?, waitForConsent?, ingestBaseUrl?, clickdBaseUrl?, adBaseUrl?
    @objc public func initialize(_ config: NSDictionary) {
        // sdkKey / sdkSecret / appId are all required by the Core (contract §5).
        guard let sdkKey = config["sdkKey"] as? String,
              let sdkSecret = config["sdkSecret"] as? String,
              let appId = config["appId"] as? String else { return }
        let core = Ja0TrackerConfig(
            sdkKey: sdkKey,
            sdkSecret: sdkSecret,
            appId: appId,
            logLevel: Self.parseLogLevel(config["logLevel"] as? String),
            waitForConsent: (config["waitForConsent"] as? Bool) ?? true,
            ingestBaseURL: (config["ingestBaseUrl"] as? String) ?? Ja0TrackerConfig.defaultIngestBaseURL,
            clickdBaseURL: (config["clickdBaseUrl"] as? String) ?? Ja0TrackerConfig.defaultClickdBaseURL,
            adBaseURL: (config["adBaseUrl"] as? String) ?? Ja0TrackerConfig.defaultAdBaseURL
        )
        Ja0Tracker.shared.initialize(core)
        wireCallbacksOnce()
    }

    @objc public func requestTrackingConsent(_ completion: @escaping (String) -> Void) {
        Task {
            let status = await Ja0Tracker.shared.requestTrackingConsent()
            completion(Self.wire(status))
        }
    }

    /// consent: analytics, attribution, ads
    @objc public func setConsent(_ consent: NSDictionary) {
        Ja0Tracker.shared.setConsent(
            Consent(
                analytics: (consent["analytics"] as? Bool) ?? false,
                attribution: (consent["attribution"] as? Bool) ?? false,
                ads: (consent["ads"] as? Bool) ?? false
            )
        )
    }

    @objc public func trackEvent(_ name: String, params: NSDictionary?) {
        Ja0Tracker.shared.trackEvent(name, (params as? [String: Any]) ?? [:])
    }

    /// Resolves to a wire dictionary for the loaded ad, or nil on no-fill.
    @objc public func loadAd(_ slotId: String, completion: @escaping (NSDictionary?) -> Void) {
        Task {
            let ad = await Ja0Tracker.shared.ads.load(slotId)
            completion(ad.map(Self.wire(_:)))
        }
    }

    // MARK: - App Ops (docs/appops-contract §5)

    /// Resolves the cached config value serialized as a JSON string, or nil.
    @objc public func getConfigJson(_ key: String, completion: @escaping (NSString?) -> Void) {
        completion(Ja0Tracker.shared.getConfigJSON(key) as NSString?)
    }

    @objc public func setPushConsent(_ granted: Bool) {
        Ja0Tracker.shared.setPushConsent(granted)
    }

    @objc public func setPushToken(_ token: String) {
        Ja0Tracker.shared.setPushToken(token)
    }

    // MARK: - Native -> JS callbacks

    private func wireCallbacksOnce() {
        guard !listenersWired else { return }
        listenersWired = true
        Ja0Tracker.shared.onAttribution { [weak self] data in
            self?.onAttribution?(Self.wire(data))
        }
        Ja0Tracker.shared.onDeepLink { [weak self] link in
            self?.onDeepLink?(Self.wire(link))
        }
        // App Ops: forward update/message to JS. The Core hands a `markShown` completion for
        // messages; call it right after emitting (delivery == shown, from RN's POV).
        Ja0Tracker.shared.onUpdateAvailable { [weak self] update in
            self?.onUpdateAvailable?(Self.wire(update))
        }
        Ja0Tracker.shared.onMessage { [weak self] msg, markShown in
            self?.onMessage?(Self.wire(msg))
            markShown()
        }
    }

    /// Forward an inbound URL to the Core (host app calls this from its URL handlers).
    @objc public func handleDeepLink(_ url: URL) {
        Ja0Tracker.shared.handleDeepLink(url)
    }

    // MARK: - Wire mapping (Core models -> NSDictionary)

    private static func parseLogLevel(_ raw: String?) -> LogLevel {
        switch raw {
        case "none": return .none
        case "error": return .error
        case "warn": return .warn
        case "debug": return .debug
        default: return .info
        }
    }

    private static func wire(_ status: TrackingConsentStatus) -> String {
        switch status {
        case .granted: return "granted"
        case .denied: return "denied"
        case .restricted: return "restricted"
        case .notDetermined: return "notDetermined"
        }
    }

    private static func wire(_ d: AttributionData) -> NSDictionary {
        return [
            "source": d.source as Any,
            "campaign": d.campaign as Any,
            "network": d.network as Any,
            "clickId": d.clickId as Any,
            "confidence": d.confidence.rawValue,
            "confidenceScore": d.confidenceScore as Any,
            "raw": d.raw,
        ]
    }

    private static func wire(_ l: DeepLinkData) -> NSDictionary {
        return [
            "path": l.path as Any,
            "params": l.params,
            "url": l.url as Any,
            "isDeferred": l.isDeferred,
        ]
    }

    private static func wire(_ u: UpdateInfo) -> NSDictionary {
        return [
            "available": u.available,
            "force": u.force,
            "latestVersion": u.latestVersion as Any,
            "storeUrl": u.storeURL as Any,
            "title": u.title as Any,
            "body": u.body as Any,
        ]
    }

    private static func wire(_ m: AppMessage) -> NSDictionary {
        return [
            "id": m.id,
            "type": m.type.rawValue,
            "priority": m.priority,
            "title": m.title as Any,
            "body": m.body as Any,
            "ctaText": m.ctaText as Any,
            "ctaUrl": m.ctaURL as Any,
            "imageUrl": m.imageURL as Any,
            "force": m.force,
            "minSessionSec": m.minSessionSec,
            "frequency": m.frequency.rawValue,
        ]
    }

    private static func wire(_ ad: NativeAd) -> NSDictionary {
        var media: NSDictionary?
        if let m = ad.assets.media {
            media = ["type": m.type.rawValue, "url": m.url]
        }
        let assets: NSDictionary = [
            "headline": ad.assets.headline as Any,
            "body": ad.assets.body as Any,
            "advertiser": ad.assets.advertiser as Any,
            "cta": ad.assets.cta as Any,
            "iconUrl": ad.assets.iconURL as Any,
            "media": media as Any,
            "rating": ad.assets.rating as Any,
        ]
        let tracking: NSDictionary = [
            "impressionUrls": ad.tracking.impressionURLs,
            "clickUrl": ad.tracking.clickURL,
            "viewableThreshold": [
                "pixels": ad.tracking.viewableThreshold.pixels,
                "ms": ad.tracking.viewableThreshold.ms,
            ],
        ]
        return [
            "slotId": ad.slotId,
            "adId": ad.adId,
            "format": ad.format,
            "assets": assets,
            "tracking": tracking,
        ]
    }
}
