#import "Mtracker.h"

// The Swift shim (`MtrackerImpl`) is exposed to ObjC via the generated
// "<ProductModuleName>-Swift.h" umbrella header. The product module name for this pod is
// `mtracker_react_native` (CocoaPods replaces '-' with '_').
#if __has_include("mtracker_react_native-Swift.h")
#import "mtracker_react_native-Swift.h"
#elif __has_include(<mtracker_react_native/mtracker_react_native-Swift.h>)
#import <mtracker_react_native/mtracker_react_native-Swift.h>
#endif

// New Architecture: the codegen spec protocol lives in the generated MtrackerSpec header.
#ifdef RCT_NEW_ARCH_ENABLED
#import <MtrackerSpec/MtrackerSpec.h>
#endif

static NSString *const kEventAttribution = @"mtracker:onAttribution";
static NSString *const kEventDeepLink = @"mtracker:onDeepLink";
static NSString *const kEventUpdate = @"mtracker:onUpdateAvailable";
static NSString *const kEventMessage = @"mtracker:onMessage";

@interface Mtracker ()
@property (nonatomic, assign) BOOL hasListeners;
@end

@implementation Mtracker

// Registers the module under the JS name "Mtracker" (matches NativeMtracker.ts).
RCT_EXPORT_MODULE(Mtracker)

// Init/UI-free work; run the module on a background queue is fine, but the Core marshals
// its own threading, so the default (main) queue is acceptable.
+ (BOOL)requiresMainQueueSetup { return NO; }

- (instancetype)init {
  if (self = [super init]) {
    __weak Mtracker *weakSelf = self;
    // Install native -> JS callbacks on the shared Swift shim. The shim registers these
    // with the Core exactly once (see MtrackerImpl.wireCallbacksOnce).
    MtrackerImpl.shared.onAttribution = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventAttribution body:payload];
    };
    MtrackerImpl.shared.onDeepLink = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventDeepLink body:payload];
    };
    MtrackerImpl.shared.onUpdateAvailable = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventUpdate body:payload];
    };
    MtrackerImpl.shared.onMessage = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventMessage body:payload];
    };
  }
  return self;
}

#pragma mark - RCTEventEmitter

- (NSArray<NSString *> *)supportedEvents {
  return @[ kEventAttribution, kEventDeepLink, kEventUpdate, kEventMessage ];
}

- (void)startObserving { self.hasListeners = YES; }
- (void)stopObserving { self.hasListeners = NO; }

- (void)sendEventSafely:(NSString *)name body:(NSDictionary *)body {
  if (self.hasListeners) {
    [self sendEventWithName:name body:body];
  }
}

#pragma mark - Exported methods (delegate to the Swift shim -> Core)

RCT_EXPORT_METHOD(initialize:(NSDictionary *)config) {
  [MtrackerImpl.shared initialize:config];
}

RCT_EXPORT_METHOD(requestTrackingConsent:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [MtrackerImpl.shared requestTrackingConsent:^(NSString *status) {
    resolve(status);
  }];
}

RCT_EXPORT_METHOD(setConsent:(NSDictionary *)consent) {
  [MtrackerImpl.shared setConsent:consent];
}

RCT_EXPORT_METHOD(trackEvent:(NSString *)name params:(NSDictionary *)params) {
  [MtrackerImpl.shared trackEvent:name params:params];
}

RCT_EXPORT_METHOD(loadAd:(NSString *)slotId
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [MtrackerImpl.shared loadAd:slotId completion:^(NSDictionary *ad) {
    resolve(ad ?: (id)kCFNull);
  }];
}

// ---- App Ops (docs/appops-contract §5) ----

RCT_EXPORT_METHOD(getConfigJson:(NSString *)key
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [MtrackerImpl.shared getConfigJson:key completion:^(NSString *value) {
    resolve(value ?: (id)kCFNull);
  }];
}

RCT_EXPORT_METHOD(setPushConsent:(BOOL)granted) {
  [MtrackerImpl.shared setPushConsent:granted];
}

RCT_EXPORT_METHOD(setPushToken:(NSString *)token) {
  [MtrackerImpl.shared setPushToken:token];
}

// NativeEventEmitter bookkeeping (required by the JS spec; RCTEventEmitter provides the
// base impls, these overrides keep the codegen contract satisfied under both archs).
RCT_EXPORT_METHOD(addListener:(NSString *)eventName) {
  [super addListener:eventName];
}

RCT_EXPORT_METHOD(removeListeners:(double)count) {
  [super removeListeners:count];
}

#pragma mark - TurboModule (New Architecture)

#ifdef RCT_NEW_ARCH_ENABLED
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
  return std::make_shared<facebook::react::NativeMtrackerSpecJSI>(params);
}
#endif

@end
