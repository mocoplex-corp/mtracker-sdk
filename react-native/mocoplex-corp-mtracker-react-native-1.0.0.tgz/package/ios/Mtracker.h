#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

// mtracker React Native — iOS TurboModule header.
//
// Exposes the module as an RCTEventEmitter so `NativeEventEmitter` in JS
// (src/index.tsx) can subscribe to `mtracker:onAttribution` / `mtracker:onDeepLink`.
// Under the New Architecture the implementation additionally conforms to the codegen
// `NativeMtrackerSpec` protocol (applied in the .mm via RCT_EXPORT_MODULE + the
// generated getTurboModule: hook).
@interface Mtracker : RCTEventEmitter <RCTBridgeModule>
@end
