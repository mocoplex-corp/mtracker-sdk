#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

// mtracker React Native — iOS TurboModule header.
//
// Exposes the module as an RCTEventEmitter so `NativeEventEmitter` in JS
// (src/index.tsx) can subscribe to `ja0tracker:onAttribution` / `ja0tracker:onDeepLink`.
// Under the New Architecture the implementation additionally conforms to the codegen
// `NativeJa0TrackerSpec` protocol (applied in the .mm via RCT_EXPORT_MODULE + the
// generated getTurboModule: hook).
@interface Ja0Tracker : RCTEventEmitter <RCTBridgeModule>
@end
