#import <React/RCTViewManager.h>

#if __has_include("ja0tracker_react_native-Swift.h")
#import "ja0tracker_react_native-Swift.h"
#elif __has_include(<ja0tracker_react_native/ja0tracker_react_native-Swift.h>)
#import <ja0tracker_react_native/ja0tracker_react_native-Swift.h>
#endif

// Legacy (old-architecture) ViewManager for `<MTNativeAd>`. Exposes the Swift
// `MTNativeAdContainerView`, which wraps the Core's `MTNativeAdView`. Under the New
// Architecture the same JS component ("MTNativeAdView") is served by the Fabric component
// in MTNativeAdComponentView.mm; RN picks the right one per arch.
@interface MTNativeAdViewManager : RCTViewManager
@end

@implementation MTNativeAdViewManager

RCT_EXPORT_MODULE(MTNativeAdView)

- (UIView *)view {
  return [MTNativeAdContainerView new];
}

// `slotId` drives the ad load; `useDefaultTemplate` mirrors the JS spec.
RCT_CUSTOM_VIEW_PROPERTY(slotId, NSString, MTNativeAdContainerView) {
  if (json) { [view setSlotId:[RCTConvert NSString:json]]; }
}
RCT_CUSTOM_VIEW_PROPERTY(useDefaultTemplate, BOOL, MTNativeAdContainerView) {
  view.useDefaultTemplate = json ? [RCTConvert BOOL:json] : YES;
}

// Direct events forwarded to JS (matches MTNativeAdViewNativeComponent.ts).
RCT_EXPORT_VIEW_PROPERTY(onAdLoaded, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onAdFailed, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onAdImpression, RCTDirectEventBlock)
RCT_EXPORT_VIEW_PROPERTY(onAdClicked, RCTDirectEventBlock)

@end
