import Foundation
import Ja0TrackerSDK
#if canImport(UIKit)
import UIKit
import React

/// Container UIView that hosts the shared Core's `MTNativeAdView` and drives the ad load.
///
/// It DELEGATES rendering + impression/click beacons to the Core view (docs/ads.md §6);
/// this container only requests the ad for `slotId` and surfaces lifecycle events to RN via
/// `RCTDirectEventBlock` properties, which the legacy `RCTViewManager` exports as
/// `onAd*` props (matching MTNativeAdViewNativeComponent.ts).
@objc(MTNativeAdContainerView)
public final class MTNativeAdContainerView: UIView {

    // RN direct-event blocks, set by the ViewManager via RCT_EXPORT_VIEW_PROPERTY.
    @objc public var onAdLoaded: RCTDirectEventBlock?
    @objc public var onAdFailed: RCTDirectEventBlock?
    @objc public var onAdImpression: RCTDirectEventBlock?
    @objc public var onAdClicked: RCTDirectEventBlock?

    private let adView = MTNativeAdView(frame: .zero)
    private var currentSlotId: String?

    public override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(adView)
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        addSubview(adView)
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        adView.frame = bounds
    }

    @objc public var useDefaultTemplate: Bool = true

    /// Setting the slot id triggers a fresh ad request. Idempotent per slot id.
    @objc public func setSlotId(_ slotId: String) {
        guard !slotId.isEmpty, slotId != currentSlotId else { return }
        currentSlotId = slotId
        Task { @MainActor in
            let ad = await Ja0Tracker.shared.ads.load(slotId)
            guard let ad else {
                self.onAdFailed?(["reason": "no-fill"])
                return
            }
            // Forward the Core view's viewability-gated beacons to RN. The Core owns the
            // actual impression/click tracking; these just surface the events to JS.
            self.adView.onImpression = { [weak self] in self?.onAdImpression?(["adId": ad.adId]) }
            self.adView.onClick = { [weak self] in self?.onAdClicked?(["adId": ad.adId]) }
            self.adView.bind(ad)
            self.onAdLoaded?(["adId": ad.adId])
        }
    }
}
#endif
