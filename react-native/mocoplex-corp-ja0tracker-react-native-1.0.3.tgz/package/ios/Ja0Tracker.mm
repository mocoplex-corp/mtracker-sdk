#import "Ja0Tracker.h"

// The Swift shim (`Ja0TrackerImpl`) is exposed to ObjC via the generated
// "<ProductModuleName>-Swift.h" umbrella header. The product module name for this pod is
// `ja0tracker_react_native` (CocoaPods replaces '-' with '_').
#if __has_include("ja0tracker_react_native-Swift.h")
#import "ja0tracker_react_native-Swift.h"
#elif __has_include(<ja0tracker_react_native/ja0tracker_react_native-Swift.h>)
#import <ja0tracker_react_native/ja0tracker_react_native-Swift.h>
#endif

// New Architecture: the codegen spec protocol lives in the generated Ja0TrackerSpec header.
#ifdef RCT_NEW_ARCH_ENABLED
#import <Ja0TrackerSpec/Ja0TrackerSpec.h>
#endif

static NSString *const kEventAttribution = @"ja0tracker:onAttribution";
static NSString *const kEventDeepLink = @"ja0tracker:onDeepLink";
static NSString *const kEventUpdate = @"ja0tracker:onUpdateAvailable";
static NSString *const kEventMessage = @"ja0tracker:onMessage";

@interface Ja0Tracker ()
@property (nonatomic, assign) BOOL hasListeners;
@end

@implementation Ja0Tracker

// Registers the module under the JS name "Ja0Tracker" (matches NativeJa0Tracker.ts).
RCT_EXPORT_MODULE(Ja0Tracker)

// Init/UI-free work; run the module on a background queue is fine, but the Core marshals
// its own threading, so the default (main) queue is acceptable.
+ (BOOL)requiresMainQueueSetup { return NO; }

- (instancetype)init {
  if (self = [super init]) {
    __weak Ja0Tracker *weakSelf = self;
    // Install native -> JS callbacks on the shared Swift shim. The shim registers these
    // with the Core exactly once (see Ja0TrackerImpl.wireCallbacksOnce).
    Ja0TrackerImpl.shared.onAttribution = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventAttribution body:payload];
    };
    Ja0TrackerImpl.shared.onDeepLink = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventDeepLink body:payload];
    };
    Ja0TrackerImpl.shared.onUpdateAvailable = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventUpdate body:payload];
    };
    Ja0TrackerImpl.shared.onMessage = ^(NSDictionary *payload) {
      [weakSelf sendEventSafely:kEventMessage body:payload];
    };
  }
  return self;
}

#pragma mark - RCTEventEmitter

- (NSArray<NSString *> *)supportedEvents {
  return @[ kEventAttribution, kEventDeepLink, kEventUpdate, kEventMessage ];
}

- (void)startObserving { self.hasListeners = YES; }
- (void)stopObserving { self.hasListeners = NO; }

- (void)sendEventSafely:(NSString *)name body:(NSDictionary *)body {
  if (self.hasListeners) {
    [self sendEventWithName:name body:body];
  }
}

#pragma mark - Exported methods (delegate to the Swift shim -> Core)

RCT_EXPORT_METHOD(initialize:(NSDictionary *)config) {
  [Ja0TrackerImpl.shared initialize:config];
}

RCT_EXPORT_METHOD(requestTrackingConsent:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [Ja0TrackerImpl.shared requestTrackingConsent:^(NSString *status) {
    resolve(status);
  }];
}

RCT_EXPORT_METHOD(setConsent:(NSDictionary *)consent) {
  [Ja0TrackerImpl.shared setConsent:consent];
}

RCT_EXPORT_METHOD(trackEvent:(NSString *)name params:(NSDictionary *)params) {
  [Ja0TrackerImpl.shared trackEvent:name params:params];
}

RCT_EXPORT_METHOD(loadAd:(NSString *)slotId
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [Ja0TrackerImpl.shared loadAd:slotId completion:^(NSDictionary *ad) {
    resolve(ad ?: (id)kCFNull);
  }];
}

// ---- App Ops (docs/appops-contract §5) ----

RCT_EXPORT_METHOD(getConfigJson:(NSString *)key
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
  [Ja0TrackerImpl.shared getConfigJson:key completion:^(NSString *value) {
    resolve(value ?: (id)kCFNull);
  }];
}

RCT_EXPORT_METHOD(setPushConsent:(BOOL)granted) {
  [Ja0TrackerImpl.shared setPushConsent:granted];
}

RCT_EXPORT_METHOD(setPushToken:(NSString *)token) {
  [Ja0TrackerImpl.shared setPushToken:token];
}

// NativeEventEmitter bookkeeping (required by the JS spec; RCTEventEmitter provides the
// base impls, these overrides keep the codegen contract satisfied under both archs).
RCT_EXPORT_METHOD(addListener:(NSString *)eventName) {
  [super addListener:eventName];
}

RCT_EXPORT_METHOD(removeListeners:(double)count) {
  [super removeListeners:count];
}

#pragma mark - TurboModule (New Architecture)

#ifdef RCT_NEW_ARCH_ENABLED
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
  return std::make_shared<facebook::react::NativeJa0TrackerSpecJSI>(params);
}
#endif

@end
