// Fabric (New Architecture) host component for `<MTNativeAd>` ("MTNativeAdView").
//
// Only compiled under the New Architecture. Wraps the same Swift
// `MTNativeAdContainerView` used by the legacy manager, so rendering + beacons stay in the
// Core view. Props/events use the codegen artifacts generated from
// MTNativeAdViewNativeComponent.ts.
#ifdef RCT_NEW_ARCH_ENABLED

#import <React/RCTViewComponentView.h>
#import <UIKit/UIKit.h>

#import <react/renderer/components/Ja0TrackerSpec/ComponentDescriptors.h>
#import <react/renderer/components/Ja0TrackerSpec/EventEmitters.h>
#import <react/renderer/components/Ja0TrackerSpec/Props.h>
#import <react/renderer/components/Ja0TrackerSpec/RCTComponentViewHelpers.h>

#if __has_include("ja0tracker_react_native-Swift.h")
#import "ja0tracker_react_native-Swift.h"
#elif __has_include(<ja0tracker_react_native/ja0tracker_react_native-Swift.h>)
#import <ja0tracker_react_native/ja0tracker_react_native-Swift.h>
#endif

using namespace facebook::react;

@interface MTNativeAdComponentView : RCTViewComponentView
@end

@implementation MTNativeAdComponentView {
  MTNativeAdContainerView *_adView;
}

+ (ComponentDescriptorProvider)componentDescriptorProvider {
  return concreteComponentDescriptorProvider<MTNativeAdViewComponentDescriptor>();
}

- (instancetype)initWithFrame:(CGRect)frame {
  if (self = [super initWithFrame:frame]) {
    static const auto defaultProps = std::make_shared<const MTNativeAdViewProps>();
    _props = defaultProps;

    _adView = [MTNativeAdContainerView new];
    __weak MTNativeAdComponentView *weakSelf = self;

    _adView.onAdLoaded = ^(NSDictionary *body) {
      MTNativeAdComponentView *strongSelf = weakSelf;
      if (!strongSelf || !strongSelf->_eventEmitter) { return; }
      std::static_pointer_cast<const MTNativeAdViewEventEmitter>(strongSelf->_eventEmitter)
          ->onAdLoaded({.adId = std::string([[body[@"adId"] description] UTF8String] ?: "")});
    };
    _adView.onAdFailed = ^(NSDictionary *body) {
      MTNativeAdComponentView *strongSelf = weakSelf;
      if (!strongSelf || !strongSelf->_eventEmitter) { return; }
      std::static_pointer_cast<const MTNativeAdViewEventEmitter>(strongSelf->_eventEmitter)
          ->onAdFailed({.reason = std::string([[body[@"reason"] description] UTF8String] ?: "")});
    };
    _adView.onAdImpression = ^(NSDictionary *body) {
      MTNativeAdComponentView *strongSelf = weakSelf;
      if (!strongSelf || !strongSelf->_eventEmitter) { return; }
      std::static_pointer_cast<const MTNativeAdViewEventEmitter>(strongSelf->_eventEmitter)
          ->onAdImpression({.adId = std::string([[body[@"adId"] description] UTF8String] ?: "")});
    };
    _adView.onAdClicked = ^(NSDictionary *body) {
      MTNativeAdComponentView *strongSelf = weakSelf;
      if (!strongSelf || !strongSelf->_eventEmitter) { return; }
      std::static_pointer_cast<const MTNativeAdViewEventEmitter>(strongSelf->_eventEmitter)
          ->onAdClicked({.adId = std::string([[body[@"adId"] description] UTF8String] ?: "")});
    };

    self.contentView = _adView;
  }
  return self;
}

- (void)updateProps:(const Props::Shared &)props oldProps:(const Props::Shared &)oldProps {
  const auto &oldViewProps = *std::static_pointer_cast<const MTNativeAdViewProps>(_props);
  const auto &newViewProps = *std::static_pointer_cast<const MTNativeAdViewProps>(props);

  if (oldViewProps.useDefaultTemplate != newViewProps.useDefaultTemplate) {
    _adView.useDefaultTemplate = newViewProps.useDefaultTemplate;
  }
  if (oldViewProps.slotId != newViewProps.slotId && !newViewProps.slotId.empty()) {
    [_adView setSlotId:[NSString stringWithUTF8String:newViewProps.slotId.c_str()]];
  }

  [super updateProps:props oldProps:oldProps];
}

@end

// Registers the Fabric class for the codegen component name.
Class<RCTComponentViewProtocol> MTNativeAdViewCls(void) {
  return MTNativeAdComponentView.class;
}

#endif // RCT_NEW_ARCH_ENABLED
