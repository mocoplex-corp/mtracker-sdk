package io.ja0tracker.reactnative

import android.view.View
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.common.MapBuilder
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.UIManagerHelper
import com.facebook.react.uimanager.annotations.ReactProp
import com.facebook.react.uimanager.events.Event
import io.ja0tracker.sdk.Ja0Tracker
import io.ja0tracker.sdk.ads.MTNativeAdView
import io.ja0tracker.sdk.ads.NativeAd
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Fabric / legacy ViewManager for `<MTNativeAd slotId="..." />`.
 *
 * Wraps the shared Core's [io.ja0tracker.sdk.ads.MTNativeAdView] — it does NOT re-render the
 * ad or reimplement impression/click beacons (the Core owns that, docs/ads.md §6). This
 * manager only:
 *   1. requests an ad for `slotId` via `Ja0Tracker.ads.load` (Core), then binds it, and
 *   2. bubbles ad lifecycle events (loaded/failed/impression/clicked) up to JS.
 *
 * Impression/click events originate inside the Core view's beacons; the Core exposes them
 * via [MTNativeAdView] callbacks (see TODO note below) which we forward as RN events.
 */
class MTNativeAdViewManager : SimpleViewManager<MTNativeAdView>() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun getName(): String = REACT_CLASS

    override fun createViewInstance(reactContext: ThemedReactContext): MTNativeAdView =
        MTNativeAdView(reactContext)

    @ReactProp(name = "slotId")
    fun setSlotId(view: MTNativeAdView, slotId: String?) {
        if (slotId.isNullOrEmpty()) return
        loadInto(view, slotId)
    }

    @ReactProp(name = "useDefaultTemplate", defaultBoolean = true)
    fun setUseDefaultTemplate(view: MTNativeAdView, useDefault: Boolean) {
        // Accepted for parity with the JS spec. The Core [MTNativeAdView] renders its own
        // built-in template; app-custom rendering is done JS-side by reading the ad from
        // Ja0Tracker.ads.load(...) instead of mounting this component, so there is nothing to
        // toggle on the native view here.
    }

    private fun loadInto(view: MTNativeAdView, slotId: String) {
        scope.launch {
            try {
                val ad: NativeAd? = Ja0Tracker.ads.load(slotId)
                if (ad == null) {
                    dispatch(view, OnAdFailed(view.id, "no-fill"))
                    return@launch
                }
                // Wire Core view lifecycle callbacks BEFORE bind so the Core beacons surface
                // to JS as onAdImpression / onAdClicked (Core owns the actual tracking).
                view.onImpression = { dispatch(view, OnAdImpression(view.id, ad.adId)) }
                view.onClick = { dispatch(view, OnAdClicked(view.id, ad.adId)) }
                view.bind(ad)
                dispatch(view, OnAdLoaded(view.id, ad.adId))
            } catch (t: Throwable) {
                dispatch(view, OnAdFailed(view.id, t.message ?: "error"))
            }
        }
    }

    private fun dispatch(view: View, event: Event<*>) {
        val ctx = view.context as? ReactContext ?: return
        UIManagerHelper
            .getEventDispatcherForReactTag(ctx, view.id)
            ?.dispatchEvent(event)
    }

    // Direct events must be registered so Fabric/legacy can route them to JS props.
    override fun getExportedCustomDirectEventTypeConstants(): Map<String, Any> =
        MapBuilder.builder<String, Any>()
            .put("onAdLoaded", MapBuilder.of("registrationName", "onAdLoaded"))
            .put("onAdFailed", MapBuilder.of("registrationName", "onAdFailed"))
            .put("onAdImpression", MapBuilder.of("registrationName", "onAdImpression"))
            .put("onAdClicked", MapBuilder.of("registrationName", "onAdClicked"))
            .build()

    companion object {
        const val REACT_CLASS = "MTNativeAdView"
    }
}
