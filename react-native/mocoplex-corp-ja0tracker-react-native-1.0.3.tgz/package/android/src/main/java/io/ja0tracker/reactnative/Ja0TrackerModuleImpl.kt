package io.ja0tracker.reactnative

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import io.ja0tracker.sdk.AppMessage
import io.ja0tracker.sdk.AttributionData
import io.ja0tracker.sdk.Consent
import io.ja0tracker.sdk.DeepLinkData
import io.ja0tracker.sdk.LogLevel
import io.ja0tracker.sdk.Ja0Tracker
import io.ja0tracker.sdk.Ja0TrackerConfig
import io.ja0tracker.sdk.TrackingConsentStatus
import io.ja0tracker.sdk.UpdateInfo
import io.ja0tracker.sdk.ads.NativeAd
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Arch-agnostic implementation of the mtracker TurboModule.
 *
 * This class holds ALL the bridging logic and is shared by the New Architecture spec
 * subclass ([Ja0TrackerModule] under src/newarch) and the legacy bridge subclass
 * (src/oldarch). It DELEGATES every call to the shared Android Core
 * (`io.ja0tracker.sdk.Ja0Tracker`) — it never reimplements HMAC signing, the event queue,
 * attribution, sessions, or ad rendering.
 *
 * Native -> JS callbacks (`onAttribution` / `onDeepLink`) are registered once against the
 * Core and re-emitted to JS through the RCTDeviceEventEmitter under the event names the
 * TS facade listens on (`src/index.tsx`).
 */
class Ja0TrackerModuleImpl(private val reactContext: ReactApplicationContext) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var listenersWired = false

    fun getName(): String = NAME

    /** config: { sdkKey, sdkSecret, appId, logLevel?, waitForConsent?, ingestBaseUrl?, clickdBaseUrl?, adBaseUrl? } */
    fun initialize(config: ReadableMap) {
        // sdkKey / sdkSecret / appId are all required by the Core (contract §5); bail if any
        // is missing rather than letting the Core throw on the require(...) guards.
        val sdkKey = config.getStringOr("sdkKey") ?: return
        val sdkSecret = config.getStringOr("sdkSecret") ?: return
        val appId = config.getStringOr("appId") ?: return
        val core = Ja0TrackerConfig(
            sdkKey = sdkKey,
            sdkSecret = sdkSecret,
            appId = appId,
            logLevel = parseLogLevel(config.getStringOr("logLevel")),
            waitForConsent = if (config.hasKey("waitForConsent")) config.getBoolean("waitForConsent") else true,
            ingestBaseUrl = config.getStringOr("ingestBaseUrl") ?: Ja0TrackerConfig.DEFAULT_INGEST_BASE_URL,
            clickdBaseUrl = config.getStringOr("clickdBaseUrl") ?: Ja0TrackerConfig.DEFAULT_CLICKD_BASE_URL,
            adBaseUrl = config.getStringOr("adBaseUrl") ?: Ja0TrackerConfig.DEFAULT_AD_BASE_URL,
        )
        Ja0Tracker.initialize(reactContext.applicationContext, core)
        wireCallbacksOnce()
    }

    fun requestTrackingConsent(promise: Promise) {
        // Core exposes a `suspend fun`; bridge it onto a coroutine and resolve the Promise.
        scope.launch {
            try {
                val status: TrackingConsentStatus = Ja0Tracker.requestTrackingConsent()
                promise.resolve(status.toWire())
            } catch (t: Throwable) {
                // Defensive: never reject in a way that could crash JS flows.
                promise.resolve(TrackingConsentStatus.NOT_DETERMINED.toWire())
            }
        }
    }

    /** consent: { analytics, attribution, ads } */
    fun setConsent(consent: ReadableMap) {
        Ja0Tracker.setConsent(
            Consent(
                analytics = consent.getBooleanOr("analytics"),
                attribution = consent.getBooleanOr("attribution"),
                ads = consent.getBooleanOr("ads"),
            )
        )
    }

    fun trackEvent(name: String, params: ReadableMap?) {
        Ja0Tracker.trackEvent(name, params?.toAnyMap() ?: emptyMap())
    }

    fun loadAd(slotId: String, promise: Promise) {
        scope.launch {
            try {
                val ad: NativeAd? = Ja0Tracker.ads.load(slotId)
                promise.resolve(ad?.toWritableMap())
            } catch (t: Throwable) {
                promise.resolve(null) // no-fill on error
            }
        }
    }

    // ---- App Ops (docs/appops-contract.md §5) ----

    /** Resolves the cached config value serialized as a JSON string, or null. */
    fun getConfigJson(key: String, promise: Promise) {
        promise.resolve(Ja0Tracker.getConfigJson(key))
    }

    fun setPushConsent(granted: Boolean) {
        Ja0Tracker.setPushConsent(granted)
    }

    fun setPushToken(token: String) {
        Ja0Tracker.setPushToken(token)
    }

    // ---- Native -> JS event plumbing ----

    /** Registers the Core callbacks once and re-emits to JS via RCTDeviceEventEmitter. */
    private fun wireCallbacksOnce() {
        if (listenersWired) return
        listenersWired = true
        Ja0Tracker.onAttribution { data -> emit(EVENT_ATTRIBUTION, data.toWritableMap()) }
        Ja0Tracker.onDeepLink { link -> emit(EVENT_DEEP_LINK, link.toWritableMap()) }
        // App Ops: forward update/message to JS. The Core hands a `markShown` completion for
        // messages; we call it immediately after emitting (delivery == shown, from RN's POV).
        Ja0Tracker.onUpdateAvailable { update -> emit(EVENT_UPDATE, update.toWritableMap()) }
        Ja0Tracker.onMessage { msg, markShown ->
            emit(EVENT_MESSAGE, msg.toWritableMap())
            markShown()
        }
    }

    private fun emit(eventName: String, payload: WritableMap) {
        if (!reactContext.hasActiveReactInstance()) return
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(eventName, payload)
    }

    companion object {
        const val NAME = "Ja0Tracker"
        const val EVENT_ATTRIBUTION = "ja0tracker:onAttribution"
        const val EVENT_DEEP_LINK = "ja0tracker:onDeepLink"
        const val EVENT_UPDATE = "ja0tracker:onUpdateAvailable"
        const val EVENT_MESSAGE = "ja0tracker:onMessage"

        private fun parseLogLevel(value: String?): LogLevel = when (value) {
            "none" -> LogLevel.NONE
            "error" -> LogLevel.ERROR
            "warn" -> LogLevel.WARN
            "debug" -> LogLevel.DEBUG
            else -> LogLevel.INFO
        }
    }
}

// ---- Wire mapping helpers (Core models <-> RN Readable/Writable) ----

private fun TrackingConsentStatus.toWire(): String = when (this) {
    TrackingConsentStatus.GRANTED -> "granted"
    TrackingConsentStatus.DENIED -> "denied"
    TrackingConsentStatus.RESTRICTED -> "restricted"
    TrackingConsentStatus.NOT_DETERMINED -> "notDetermined"
}

private fun AttributionData.toWritableMap(): WritableMap = Arguments.createMap().apply {
    putStringOrNull("source", source)
    putStringOrNull("campaign", campaign)
    putStringOrNull("network", network)
    putStringOrNull("clickId", clickId)
    putString("confidence", confidence.name.lowercase())
    if (confidenceScore != null) putDouble("confidenceScore", confidenceScore!!) else putNull("confidenceScore")
    putMap("raw", raw.toStringWritableMap())
}

private fun DeepLinkData.toWritableMap(): WritableMap = Arguments.createMap().apply {
    putStringOrNull("path", path)
    putMap("params", params.toStringWritableMap())
    putStringOrNull("url", url)
    putBoolean("isDeferred", isDeferred)
}

private fun UpdateInfo.toWritableMap(): WritableMap = Arguments.createMap().apply {
    putBoolean("available", available)
    putBoolean("force", force)
    putStringOrNull("latestVersion", latestVersion)
    putStringOrNull("storeUrl", storeUrl)
    putStringOrNull("title", title)
    putStringOrNull("body", body)
}

private fun AppMessage.toWritableMap(): WritableMap = Arguments.createMap().apply {
    putString("id", id)
    putString("type", type.name.lowercase())
    putInt("priority", priority)
    putStringOrNull("title", title)
    putStringOrNull("body", body)
    putStringOrNull("ctaText", ctaText)
    putStringOrNull("ctaUrl", ctaUrl)
    putStringOrNull("imageUrl", imageUrl)
    putBoolean("force", force)
    putInt("minSessionSec", minSessionSec)
    putString("frequency", frequency.name.lowercase())
}

private fun NativeAd.toWritableMap(): WritableMap = Arguments.createMap().apply {
    putString("slotId", slotId)
    putString("adId", adId)
    putString("format", format)
    putMap("assets", Arguments.createMap().apply {
        putStringOrNull("headline", assets.headline)
        putStringOrNull("body", assets.body)
        putStringOrNull("advertiser", assets.advertiser)
        putStringOrNull("cta", assets.cta)
        putStringOrNull("iconUrl", assets.iconUrl)
        val media = assets.media
        if (media != null) {
            putMap("media", Arguments.createMap().apply {
                putString("type", media.type.name.lowercase())
                putString("url", media.url)
            })
        } else {
            putNull("media")
        }
        if (assets.rating != null) putDouble("rating", assets.rating!!) else putNull("rating")
    })
    putMap("tracking", Arguments.createMap().apply {
        val urls = Arguments.createArray()
        tracking.impressionUrls.forEach { urls.pushString(it) }
        putArray("impressionUrls", urls)
        putString("clickUrl", tracking.clickUrl)
        putMap("viewableThreshold", Arguments.createMap().apply {
            putDouble("pixels", tracking.viewableThreshold.pixels)
            putDouble("ms", tracking.viewableThreshold.ms.toDouble())
        })
    })
}

private fun Map<String, String>.toStringWritableMap(): WritableMap = Arguments.createMap().apply {
    forEach { (k, v) -> putString(k, v) }
}

private fun WritableMap.putStringOrNull(key: String, value: String?) {
    if (value != null) putString(key, value) else putNull(key)
}

private fun ReadableMap.getStringOr(key: String): String? =
    if (hasKey(key) && !isNull(key)) getString(key) else null

private fun ReadableMap.getBooleanOr(key: String, default: Boolean = false): Boolean =
    if (hasKey(key) && !isNull(key)) getBoolean(key) else default

/** Converts a JS params object into a Kotlin map the Core's trackEvent accepts. */
private fun ReadableMap.toAnyMap(): Map<String, Any?> = toHashMap()
