package io.ja0tracker.reactnative

import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.module.annotations.ReactModule

/**
 * Legacy (old-architecture / bridge) entrypoint. Only compiled when
 * `newArchEnabled=false` (see the sourceSets split in build.gradle).
 *
 * Same public surface as the TurboModule spec; forwards to the shared
 * [Ja0TrackerModuleImpl], which delegates to the native Core.
 */
@ReactModule(name = Ja0TrackerModuleImpl.NAME)
class Ja0TrackerModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    private val impl = Ja0TrackerModuleImpl(reactContext)

    override fun getName(): String = Ja0TrackerModuleImpl.NAME

    @ReactMethod
    fun initialize(config: ReadableMap) = impl.initialize(config)

    @ReactMethod
    fun requestTrackingConsent(promise: Promise) = impl.requestTrackingConsent(promise)

    @ReactMethod
    fun setConsent(consent: ReadableMap) = impl.setConsent(consent)

    @ReactMethod
    fun trackEvent(name: String, params: ReadableMap?) = impl.trackEvent(name, params)

    @ReactMethod
    fun loadAd(slotId: String, promise: Promise) = impl.loadAd(slotId, promise)

    @ReactMethod
    fun getConfigJson(key: String, promise: Promise) = impl.getConfigJson(key, promise)

    @ReactMethod
    fun setPushConsent(granted: Boolean) = impl.setPushConsent(granted)

    @ReactMethod
    fun setPushToken(token: String) = impl.setPushToken(token)

    // NativeEventEmitter plumbing (required by JS-side subscription bookkeeping).
    @ReactMethod
    fun addListener(eventName: String) { /* no-op: events pushed from the Core */ }

    @ReactMethod
    fun removeListeners(count: Double) { /* no-op */ }
}
