/**
 * ja0tracker React Native SDK — public API.
 *
 * Mirrors the shared cross-platform facade (docs/sdk.md §2). This is a thin wrapper over
 * the native iOS/Android cores (`sdk/ios`, `sdk/android`) via a TurboModule + Fabric
 * native component. All calls are defensively wrapped so SDK failures never crash the
 * host app (docs/sdk.md §5).
 */
import { NativeEventEmitter, NativeModules } from 'react-native';
import NativeJa0Tracker from './NativeJa0Tracker';

export { default as MTNativeAd } from './MTNativeAd';
export type { MTNativeAdProps } from './MTNativeAd';

// ---- Public types (mirror Android/iOS models) ----

export type LogLevel = 'none' | 'error' | 'warn' | 'info' | 'debug';

export interface Ja0TrackerConfig {
  /** Tenant SDK public key issued by the ja0 console. Required (SDK contract §5). */
  sdkKey: string;
  /**
   * Tenant HMAC secret issued alongside `sdkKey` (SDK contract §2). Used by the native
   * Core to sign event batches; embedded-secret limits are documented in the contract.
   * Required — the native cores refuse to initialize without it.
   */
  sdkSecret: string;
  /** App id (UUID) issued by the dashboard (SDK contract §3). Required. */
  appId: string;
  logLevel?: LogLevel;
  /** Privacy-first default: gate deterministic/fingerprint matching on consent. */
  waitForConsent?: boolean;
  /** Configurable backend base URLs (override the live defaults). */
  ingestBaseUrl?: string;
  clickdBaseUrl?: string;
  /** Native ad request host (adserver is internal today; override when it goes public). */
  adBaseUrl?: string;
}

export interface Consent {
  analytics: boolean;
  attribution: boolean;
  ads: boolean;
}

export type TrackingConsentStatus =
  | 'granted'
  | 'denied'
  | 'restricted'
  | 'notDetermined';

export type AttributionConfidence =
  | 'deterministic'
  | 'probabilistic'
  | 'aggregate'
  | 'organic';

export interface AttributionData {
  source: string | null;
  campaign: string | null;
  network: string | null;
  clickId: string | null;
  confidence: AttributionConfidence;
  /** 0.0–1.0, meaningful only for probabilistic matches. */
  confidenceScore?: number | null;
  raw?: Record<string, string>;
}

export interface DeepLinkData {
  path: string | null;
  params: Record<string, string>;
  url?: string | null;
  isDeferred: boolean;
}

// Native ad asset model (docs/ads.md §6).
export interface NativeAdMedia {
  type: 'image' | 'video';
  url: string;
}

export interface NativeAdAssets {
  headline?: string | null;
  body?: string | null;
  advertiser?: string | null;
  cta?: string | null;
  iconUrl?: string | null;
  media?: NativeAdMedia | null;
  rating?: number | null;
}

export interface NativeAdTracking {
  impressionUrls: string[];
  clickUrl: string;
  viewableThreshold: { pixels: number; ms: number };
}

export interface NativeAd {
  slotId: string;
  adId: string;
  format: string;
  assets: NativeAdAssets;
  tracking: NativeAdTracking;
}

// ---- App Ops types (docs/appops-contract.md §2, §5) ----

/** Server-driven version-update prompt (already localized to the device language). */
export interface UpdateInfo {
  available: boolean;
  force: boolean;
  latestVersion: string | null;
  storeUrl: string | null;
  title: string | null;
  body: string | null;
}

export type AppMessageType = 'update' | 'announcement' | 'review' | 'custom';
export type AppMessageFrequency = 'once' | 'session' | 'daily' | 'always';

/** In-app message / announcement / review prompt (already localized). */
export interface AppMessage {
  id: string;
  type: AppMessageType;
  priority: number;
  title: string | null;
  body: string | null;
  ctaText: string | null;
  ctaUrl: string | null;
  imageUrl: string | null;
  force: boolean;
  minSessionSec: number;
  frequency: AppMessageFrequency;
}

// ---- Event plumbing ----

const EVENT_ATTRIBUTION = 'ja0tracker:onAttribution';
const EVENT_DEEP_LINK = 'ja0tracker:onDeepLink';
const EVENT_UPDATE = 'ja0tracker:onUpdateAvailable';
const EVENT_MESSAGE = 'ja0tracker:onMessage';

// The emitter is created against the underlying native module. NativeJa0Tracker is the
// codegen'd spec proxy; NativeModules.Ja0Tracker is the same instance for the emitter.
const emitter = new NativeEventEmitter(NativeModules.Ja0Tracker);

export type Unsubscribe = () => void;

// ---- Public facade ----

function safe(fn: () => void): void {
  try {
    fn();
  } catch {
    // Swallow — SDK failures must not crash the host app (docs/sdk.md §5).
  }
}

/** Fetches a raw config JSON string from the native cache; null on error/absent. */
async function getConfigRaw(key: string): Promise<string | null> {
  try {
    return (await NativeJa0Tracker.getConfigJson(key)) ?? null;
  } catch {
    return null;
  }
}

export const Ja0Tracker = {
  /** Initialize once at app start. */
  initialize(config: Ja0TrackerConfig): void {
    // Apply defaults without clobbering caller-provided values.
    safe(() =>
      NativeJa0Tracker.initialize({
        logLevel: 'info',
        waitForConsent: true,
        ...config,
      } as unknown as object)
    );
  },

  /** iOS: triggers the ATT prompt. Android: resolves to "granted" (no-op). */
  async requestTrackingConsent(): Promise<TrackingConsentStatus> {
    try {
      const status = await NativeJa0Tracker.requestTrackingConsent();
      return status as TrackingConsentStatus;
    } catch {
      return 'notDetermined';
    }
  },

  setConsent(consent: Consent): void {
    safe(() => NativeJa0Tracker.setConsent(consent));
  },

  /** Register the attribution callback. Returns an unsubscribe fn. */
  onAttribution(cb: (data: AttributionData) => void): Unsubscribe {
    const sub = emitter.addListener(EVENT_ATTRIBUTION, cb);
    return () => sub.remove();
  },

  /** Register the deferred/live deep link callback. Returns an unsubscribe fn. */
  onDeepLink(cb: (data: DeepLinkData) => void): Unsubscribe {
    const sub = emitter.addListener(EVENT_DEEP_LINK, cb);
    return () => sub.remove();
  },

  trackEvent(name: string, params: Record<string, unknown> = {}): void {
    safe(() => NativeJa0Tracker.trackEvent(name, params));
  },

  // ---- App Ops: remote config (docs/appops-contract.md §5) ----

  /** Returns a cached remote-config string, or `defaultValue` when absent. */
  async getConfigString(
    key: string,
    defaultValue: string | null = null
  ): Promise<string | null> {
    const raw = await getConfigRaw(key);
    return raw ?? defaultValue;
  },

  /** Returns a cached remote-config boolean, or `defaultValue` when absent. */
  async getConfigBool(key: string, defaultValue: boolean): Promise<boolean> {
    const raw = await getConfigRaw(key);
    if (raw == null) return defaultValue;
    return raw === 'true' || raw === '1';
  },

  /** Returns a cached remote-config integer, or `defaultValue` when absent. */
  async getConfigInt(key: string, defaultValue: number): Promise<number> {
    const raw = await getConfigRaw(key);
    if (raw == null) return defaultValue;
    const n = Number.parseInt(raw, 10);
    return Number.isNaN(n) ? defaultValue : n;
  },

  /** Returns a cached remote-config value parsed from JSON (object/array/scalar), or null. */
  async getConfigJson<T = unknown>(key: string): Promise<T | null> {
    const raw = await getConfigRaw(key);
    if (raw == null) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return raw as unknown as T;
    }
  },

  // ---- App Ops: update / message callbacks (docs/appops-contract.md §5) ----

  /**
   * Override the default update popup. Receives the localized UpdateInfo; render your own
   * UI and open `storeUrl` for the CTA (make `force` updates blocking). Returns unsubscribe.
   */
  onUpdateAvailable(cb: (data: UpdateInfo) => void): Unsubscribe {
    const sub = emitter.addListener(EVENT_UPDATE, cb);
    return () => sub.remove();
  },

  /**
   * Override the default in-app message UI. Receives the localized AppMessage. The native
   * side records frequency on delivery; render your own UI (announcement/custom) or handle
   * review as you wish. Returns unsubscribe.
   */
  onMessage(cb: (data: AppMessage) => void): Unsubscribe {
    const sub = emitter.addListener(EVENT_MESSAGE, cb);
    return () => sub.remove();
  },

  // ---- App Ops: push (docs/appops-contract.md §3) ----

  /** Consent gate for push registration; queued tokens are sent once granted. */
  setPushConsent(granted: boolean): void {
    safe(() => NativeJa0Tracker.setPushConsent(granted));
  },

  /** Register an FCM/APNs token (host owns push setup). POSTed once consent is granted. */
  setPushToken(token: string): void {
    safe(() => NativeJa0Tracker.setPushToken(token));
  },

  ads: {
    /** Load a native ad by slot ID (docs/ads.md). Resolves null on no-fill. */
    async load(slotId: string): Promise<NativeAd | null> {
      try {
        const ad = await NativeJa0Tracker.loadAd(slotId);
        return (ad as NativeAd | null) ?? null;
      } catch {
        return null;
      }
    },
  },
};

export default Ja0Tracker;
