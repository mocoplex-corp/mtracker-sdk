import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';
import type { UnsafeObject } from 'react-native/Libraries/Types/CodegenTypes';

/**
 * TurboModule spec (New Architecture / codegen).
 *
 * Codegen constraints: only primitives, arrays, and object literals are allowed here —
 * no TS unions/enums. Rich public types live in `index.tsx`, which maps to/from these
 * plain shapes. Callbacks are delivered as JSI events via the NativeEventEmitter
 * (see `index.tsx` — `onAttribution` / `onDeepLink`).
 *
 * TODO(native): implement the native side of this spec:
 *   - iOS  -> ios/Ja0Tracker.mm bridging to `sdk/ios` (Ja0Tracker.shared)
 *   - Android -> android/.../Ja0TrackerModule.kt bridging to `sdk/android` (io.ja0tracker.sdk.Ja0Tracker)
 */
export interface Spec extends TurboModule {
  /** config: { sdkKey, sdkSecret, appId, logLevel?, waitForConsent?, ingestBaseUrl?, clickdBaseUrl?, adBaseUrl? } */
  initialize(config: UnsafeObject): void;

  /** Resolves to a status string: "granted" | "denied" | "restricted" | "notDetermined". */
  requestTrackingConsent(): Promise<string>;

  /** consent: { analytics, attribution, ads } */
  setConsent(consent: UnsafeObject): void;

  /** params is a JSON-serializable object of event properties. */
  trackEvent(name: string, params: UnsafeObject): void;

  /** Resolves to a NativeAd object (see docs/ads.md §6) or null on no-fill. */
  loadAd(slotId: string): Promise<UnsafeObject | null>;

  // ---- App Ops (docs/appops-contract.md §5) ----

  /**
   * Returns a cached remote-config value as a JSON string (so codegen stays primitive-only):
   *   string  -> the raw string, bool -> "true"/"false", number -> its decimal text,
   *   object/array -> JSON. Resolves the native default when the key is absent.
   * The JS facade parses this back into typed getters.
   */
  getConfigJson(key: string): Promise<string | null>;

  /** Register push consent gate; queued tokens are sent once granted. */
  setPushConsent(granted: boolean): void;

  /** Register an FCM/APNs token (host owns push setup). POSTed once consent is granted. */
  setPushToken(token: string): void;

  // NativeEventEmitter plumbing (required by codegen for event-emitting modules).
  addListener(eventName: string): void;
  removeListeners(count: number): void;
}

export default TurboModuleRegistry.getEnforcing<Spec>('Ja0Tracker');
