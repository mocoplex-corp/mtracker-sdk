/**
 * `<MTNativeAd slotId="home_feed_slot" />` — renders a native ad in a slot.
 *
 * Thin React wrapper over the Fabric native component
 * (`MTNativeAdViewNativeComponent`), which bridges to the native `MTNativeAdView`
 * in `sdk/ios` / `sdk/android`. The native side owns rendering + impression/click
 * beacons (docs/ads.md §6).
 */
import * as React from 'react';
import type { ViewStyle } from 'react-native';
export interface MTNativeAdProps {
    slotId: string;
    style?: ViewStyle;
    /** Use the SDK's built-in template (true) vs. app-custom rendering (false). */
    useDefaultTemplate?: boolean;
    onAdLoaded?: (e: {
        adId: string;
    }) => void;
    onAdFailed?: (e: {
        reason: string;
    }) => void;
    onAdImpression?: (e: {
        adId: string;
    }) => void;
    onAdClicked?: (e: {
        adId: string;
    }) => void;
}
export default function MTNativeAd(props: MTNativeAdProps): React.ReactElement;
//# sourceMappingURL=MTNativeAd.d.ts.map